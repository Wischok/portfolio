<!DOCTYPE html>
<html lang="en-US" class="no-js">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" /><script type="text/javascript">(window.NREUM||(NREUM={})).init={ajax:{deny_list:["bam.nr-data.net"]}};(window.NREUM||(NREUM={})).loader_config={licenseKey:"NRJS-4e4110d68b3ad07705c",applicationID:"576718860"};;/*! For license information please see nr-loader-rum-1.274.0.min.js.LICENSE.txt */
(()=>{var e,t,r={8122:(e,t,r)=>{"use strict";r.d(t,{a:()=>i});var n=r(944);function i(e,t){try{if(!e||"object"!=typeof e)return(0,n.R)(3);if(!t||"object"!=typeof t)return(0,n.R)(4);const r=Object.create(Object.getPrototypeOf(t),Object.getOwnPropertyDescriptors(t)),o=0===Object.keys(r).length?e:r;for(let a in o)if(void 0!==e[a])try{if(null===e[a]){r[a]=null;continue}Array.isArray(e[a])&&Array.isArray(t[a])?r[a]=Array.from(new Set([...e[a],...t[a]])):"object"==typeof e[a]&&"object"==typeof t[a]?r[a]=i(e[a],t[a]):r[a]=e[a]}catch(e){(0,n.R)(1,e)}return r}catch(e){(0,n.R)(2,e)}}},2555:(e,t,r)=>{"use strict";r.d(t,{Vp:()=>c,fn:()=>s,x1:()=>u});var n=r(384),i=r(8122);const o={beacon:n.NT.beacon,errorBeacon:n.NT.errorBeacon,licenseKey:void 0,applicationID:void 0,sa:void 0,queueTime:void 0,applicationTime:void 0,ttGuid:void 0,user:void 0,account:void 0,product:void 0,extra:void 0,jsAttributes:{},userAttributes:void 0,atts:void 0,transactionName:void 0,tNamePlain:void 0},a={};function s(e){try{const t=c(e);return!!t.licenseKey&&!!t.errorBeacon&&!!t.applicationID}catch(e){return!1}}function c(e){if(!e)throw new Error("All info objects require an agent identifier!");if(!a[e])throw new Error("Info for ".concat(e," was never set"));return a[e]}function u(e,t){if(!e)throw new Error("All info objects require an agent identifier!");a[e]=(0,i.a)(t,o);const r=(0,n.nY)(e);r&&(r.info=a[e])}},9417:(e,t,r)=>{"use strict";r.d(t,{D0:()=>g,gD:()=>h,xN:()=>p});var n=r(993);const i=e=>{if(!e||"string"!=typeof e)return!1;try{document.createDocumentFragment().querySelector(e)}catch{return!1}return!0};var o=r(2614),a=r(944),s=r(384),c=r(8122);const u="[data-nr-mask]",d=()=>{const e={mask_selector:"*",block_selector:"[data-nr-block]",mask_input_options:{color:!1,date:!1,"datetime-local":!1,email:!1,month:!1,number:!1,range:!1,search:!1,tel:!1,text:!1,time:!1,url:!1,week:!1,textarea:!1,select:!1,password:!0}};return{ajax:{deny_list:void 0,block_internal:!0,enabled:!0,harvestTimeSeconds:10,autoStart:!0},distributed_tracing:{enabled:void 0,exclude_newrelic_header:void 0,cors_use_newrelic_header:void 0,cors_use_tracecontext_headers:void 0,allowed_origins:void 0},feature_flags:[],generic_events:{enabled:!0,harvestTimeSeconds:30,autoStart:!0},harvest:{tooManyRequestsDelay:60},jserrors:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},logging:{enabled:!0,harvestTimeSeconds:10,autoStart:!0,level:n.p_.INFO},metrics:{enabled:!0,autoStart:!0},obfuscate:void 0,page_action:{enabled:!0},page_view_event:{enabled:!0,autoStart:!0},page_view_timing:{enabled:!0,harvestTimeSeconds:30,autoStart:!0},performance:{capture_marks:!1,capture_measures:!1},privacy:{cookies_enabled:!0},proxy:{assets:void 0,beacon:void 0},session:{expiresMs:o.wk,inactiveMs:o.BB},session_replay:{autoStart:!0,enabled:!1,harvestTimeSeconds:60,preload:!1,sampling_rate:10,error_sampling_rate:100,collect_fonts:!1,inline_images:!1,fix_stylesheets:!0,mask_all_inputs:!0,get mask_text_selector(){return e.mask_selector},set mask_text_selector(t){i(t)?e.mask_selector="".concat(t,",").concat(u):""===t||null===t?e.mask_selector=u:(0,a.R)(5,t)},get block_class(){return"nr-block"},get ignore_class(){return"nr-ignore"},get mask_text_class(){return"nr-mask"},get block_selector(){return e.block_selector},set block_selector(t){i(t)?e.block_selector+=",".concat(t):""!==t&&(0,a.R)(6,t)},get mask_input_options(){return e.mask_input_options},set mask_input_options(t){t&&"object"==typeof t?e.mask_input_options={...t,password:!0}:(0,a.R)(7,t)}},session_trace:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},soft_navigations:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},spa:{enabled:!0,harvestTimeSeconds:10,autoStart:!0},ssl:void 0,user_actions:{enabled:!0}}},l={},f="All configuration objects require an agent identifier!";function g(e){if(!e)throw new Error(f);if(!l[e])throw new Error("Configuration for ".concat(e," was never set"));return l[e]}function p(e,t){if(!e)throw new Error(f);l[e]=(0,c.a)(t,d());const r=(0,s.nY)(e);r&&(r.init=l[e])}function h(e,t){if(!e)throw new Error(f);var r=g(e);if(r){for(var n=t.split("."),i=0;i<n.length-1;i++)if("object"!=typeof(r=r[n[i]]))return;r=r[n[n.length-1]]}return r}},3371:(e,t,r)=>{"use strict";r.d(t,{V:()=>f,f:()=>l});var n=r(8122),i=r(384),o=r(6154),a=r(9324);let s=0;const c={buildEnv:a.F3,distMethod:a.Xs,version:a.xv,originTime:o.WN},u={customTransaction:void 0,disabled:!1,isolatedBacklog:!1,loaderType:void 0,maxBytes:3e4,onerror:void 0,ptid:void 0,releaseIds:{},appMetadata:{},session:void 0,denyList:void 0,timeKeeper:void 0,obfuscator:void 0},d={};function l(e){if(!e)throw new Error("All runtime objects require an agent identifier!");if(!d[e])throw new Error("Runtime for ".concat(e," was never set"));return d[e]}function f(e,t){if(!e)throw new Error("All runtime objects require an agent identifier!");d[e]={...(0,n.a)(t,u),...c},Object.hasOwnProperty.call(d[e],"harvestCount")||Object.defineProperty(d[e],"harvestCount",{get:()=>++s});const r=(0,i.nY)(e);r&&(r.runtime=d[e])}},9324:(e,t,r)=>{"use strict";r.d(t,{F3:()=>i,Xs:()=>o,xv:()=>n});const n="1.274.0",i="PROD",o="CDN"},6154:(e,t,r)=>{"use strict";r.d(t,{OF:()=>c,RI:()=>i,WN:()=>d,bv:()=>o,gm:()=>a,mw:()=>s,sb:()=>u});var n=r(1863);const i="undefined"!=typeof window&&!!window.document,o="undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self.navigator instanceof WorkerNavigator||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis.navigator instanceof WorkerNavigator),a=i?window:"undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis),s=Boolean("hidden"===a?.document?.visibilityState),c=/iPad|iPhone|iPod/.test(a.navigator?.userAgent),u=c&&"undefined"==typeof SharedWorker,d=((()=>{const e=a.navigator?.userAgent?.match(/Firefox[/\s](\d+\.\d+)/);Array.isArray(e)&&e.length>=2&&e[1]})(),Date.now()-(0,n.t)())},1687:(e,t,r)=>{"use strict";r.d(t,{Ak:()=>c,Ze:()=>l,x3:()=>u});var n=r(7836),i=r(3606),o=r(860),a=r(2646);const s={};function c(e,t){const r={staged:!1,priority:o.P3[t]||0};d(e),s[e].get(t)||s[e].set(t,r)}function u(e,t){e&&s[e]&&(s[e].get(t)&&s[e].delete(t),g(e,t,!1),s[e].size&&f(e))}function d(e){if(!e)throw new Error("agentIdentifier required");s[e]||(s[e]=new Map)}function l(e="",t="feature",r=!1){if(d(e),!e||!s[e].get(t)||r)return g(e,t);s[e].get(t).staged=!0,f(e)}function f(e){const t=Array.from(s[e]);t.every((([e,t])=>t.staged))&&(t.sort(((e,t)=>e[1].priority-t[1].priority)),t.forEach((([t])=>{s[e].delete(t),g(e,t)})))}function g(e,t,r=!0){const o=e?n.ee.get(e):n.ee,s=i.i.handlers;if(!o.aborted&&o.backlog&&s){if(r){const e=o.backlog[t],r=s[t];if(r){for(let t=0;e&&t<e.length;++t)p(e[t],r);Object.entries(r).forEach((([e,t])=>{Object.values(t||{}).forEach((t=>{t[0]?.on&&t[0]?.context()instanceof a.y&&t[0].on(e,t[1])}))}))}}o.isolatedBacklog||delete s[t],o.backlog[t]=null,o.emit("drain-"+t,[])}}function p(e,t){var r=e[1];Object.values(t[r]||{}).forEach((t=>{var r=e[0];if(t[0]===r){var n=t[1],i=e[3],o=e[2];n.apply(i,o)}}))}},7836:(e,t,r)=>{"use strict";r.d(t,{P:()=>c,ee:()=>u});var n=r(384),i=r(8990),o=r(3371),a=r(2646),s=r(5607);const c="nr@context:".concat(s.W),u=function e(t,r){var n={},s={},d={},l=!1;try{l=16===r.length&&(0,o.f)(r).isolatedBacklog}catch(e){}var f={on:p,addEventListener:p,removeEventListener:function(e,t){var r=n[e];if(!r)return;for(var i=0;i<r.length;i++)r[i]===t&&r.splice(i,1)},emit:function(e,r,n,i,o){!1!==o&&(o=!0);if(u.aborted&&!i)return;t&&o&&t.emit(e,r,n);for(var a=g(n),c=h(e),d=c.length,l=0;l<d;l++)c[l].apply(a,r);var p=m()[s[e]];p&&p.push([f,e,r,a]);return a},get:v,listeners:h,context:g,buffer:function(e,t){const r=m();if(t=t||"feature",f.aborted)return;Object.entries(e||{}).forEach((([e,n])=>{s[n]=t,t in r||(r[t]=[])}))},abort:function(){f._aborted=!0,Object.keys(f.backlog).forEach((e=>{delete f.backlog[e]}))},isBuffering:function(e){return!!m()[s[e]]},debugId:r,backlog:l?{}:t&&"object"==typeof t.backlog?t.backlog:{},isolatedBacklog:l};return Object.defineProperty(f,"aborted",{get:()=>{let e=f._aborted||!1;return e||(t&&(e=t.aborted),e)}}),f;function g(e){return e&&e instanceof a.y?e:e?(0,i.I)(e,c,(()=>new a.y(c))):new a.y(c)}function p(e,t){n[e]=h(e).concat(t)}function h(e){return n[e]||[]}function v(t){return d[t]=d[t]||e(f,t)}function m(){return f.backlog}}(void 0,"globalEE"),d=(0,n.Zm)();d.ee||(d.ee=u)},2646:(e,t,r)=>{"use strict";r.d(t,{y:()=>n});class n{constructor(e){this.contextId=e}}},9908:(e,t,r)=>{"use strict";r.d(t,{d:()=>n,p:()=>i});var n=r(7836).ee.get("handle");function i(e,t,r,i,o){o?(o.buffer([e],i),o.emit(e,t,r)):(n.buffer([e],i),n.emit(e,t,r))}},3606:(e,t,r)=>{"use strict";r.d(t,{i:()=>o});var n=r(9908);o.on=a;var i=o.handlers={};function o(e,t,r,o){a(o||n.d,i,e,t,r)}function a(e,t,r,i,o){o||(o="feature"),e||(e=n.d);var a=t[o]=t[o]||{};(a[r]=a[r]||[]).push([e,i])}},3878:(e,t,r)=>{"use strict";function n(e,t){return{capture:e,passive:!1,signal:t}}function i(e,t,r=!1,i){window.addEventListener(e,t,n(r,i))}function o(e,t,r=!1,i){document.addEventListener(e,t,n(r,i))}r.d(t,{DD:()=>o,jT:()=>n,sp:()=>i})},5607:(e,t,r)=>{"use strict";r.d(t,{W:()=>n});const n=(0,r(9566).bz)()},9566:(e,t,r)=>{"use strict";r.d(t,{LA:()=>s,bz:()=>a});var n=r(6154);const i="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";function o(e,t){return e?15&e[t]:16*Math.random()|0}function a(){const e=n.gm?.crypto||n.gm?.msCrypto;let t,r=0;return e&&e.getRandomValues&&(t=e.getRandomValues(new Uint8Array(30))),i.split("").map((e=>"x"===e?o(t,r++).toString(16):"y"===e?(3&o()|8).toString(16):e)).join("")}function s(e){const t=n.gm?.crypto||n.gm?.msCrypto;let r,i=0;t&&t.getRandomValues&&(r=t.getRandomValues(new Uint8Array(e)));const a=[];for(var s=0;s<e;s++)a.push(o(r,i++).toString(16));return a.join("")}},2614:(e,t,r)=>{"use strict";r.d(t,{BB:()=>a,H3:()=>n,g:()=>u,iL:()=>c,tS:()=>s,uh:()=>i,wk:()=>o});const n="NRBA",i="SESSION",o=144e5,a=18e5,s={STARTED:"session-started",PAUSE:"session-pause",RESET:"session-reset",RESUME:"session-resume",UPDATE:"session-update"},c={SAME_TAB:"same-tab",CROSS_TAB:"cross-tab"},u={OFF:0,FULL:1,ERROR:2}},1863:(e,t,r)=>{"use strict";function n(){return Math.floor(performance.now())}r.d(t,{t:()=>n})},944:(e,t,r)=>{"use strict";function n(e,t){"function"==typeof console.debug&&console.debug("New Relic Warning: https://github.com/newrelic/newrelic-browser-agent/blob/main/docs/warning-codes.md#".concat(e),t)}r.d(t,{R:()=>n})},5284:(e,t,r)=>{"use strict";r.d(t,{t:()=>c,B:()=>s});var n=r(7836),i=r(6154);const o="newrelic";const a=new Set,s={};function c(e,t){const r=n.ee.get(t);s[t]??={},e&&"object"==typeof e&&(a.has(t)||(r.emit("rumresp",[e]),s[t]=e,a.add(t),function(e={}){try{i.gm.dispatchEvent(new CustomEvent(o,{detail:e}))}catch(e){}}({loaded:!0})))}},8990:(e,t,r)=>{"use strict";r.d(t,{I:()=>i});var n=Object.prototype.hasOwnProperty;function i(e,t,r){if(n.call(e,t))return e[t];var i=r();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:i,writable:!0,enumerable:!1}),i}catch(e){}return e[t]=i,i}},6389:(e,t,r)=>{"use strict";function n(e,t=500,r={}){const n=r?.leading||!1;let i;return(...r)=>{n&&void 0===i&&(e.apply(this,r),i=setTimeout((()=>{i=clearTimeout(i)}),t)),n||(clearTimeout(i),i=setTimeout((()=>{e.apply(this,r)}),t))}}function i(e){let t=!1;return(...r)=>{t||(t=!0,e.apply(this,r))}}r.d(t,{J:()=>i,s:()=>n})},5289:(e,t,r)=>{"use strict";r.d(t,{GG:()=>o,sB:()=>a});var n=r(3878);function i(){return"undefined"==typeof document||"complete"===document.readyState}function o(e,t){if(i())return e();(0,n.sp)("load",e,t)}function a(e){if(i())return e();(0,n.DD)("DOMContentLoaded",e)}},384:(e,t,r)=>{"use strict";r.d(t,{NT:()=>o,US:()=>d,Zm:()=>a,bQ:()=>c,dV:()=>s,nY:()=>u,pV:()=>l});var n=r(6154),i=r(1863);const o={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net"};function a(){return n.gm.NREUM||(n.gm.NREUM={}),void 0===n.gm.newrelic&&(n.gm.newrelic=n.gm.NREUM),n.gm.NREUM}function s(){let e=a();return e.o||(e.o={ST:n.gm.setTimeout,SI:n.gm.setImmediate,CT:n.gm.clearTimeout,XHR:n.gm.XMLHttpRequest,REQ:n.gm.Request,EV:n.gm.Event,PR:n.gm.Promise,MO:n.gm.MutationObserver,FETCH:n.gm.fetch,WS:n.gm.WebSocket}),e}function c(e,t){let r=a();r.initializedAgents??={},t.initializedAt={ms:(0,i.t)(),date:new Date},r.initializedAgents[e]=t}function u(e){let t=a();return t.initializedAgents?.[e]}function d(e,t){a()[e]=t}function l(){return function(){let e=a();const t=e.info||{};e.info={beacon:o.beacon,errorBeacon:o.errorBeacon,...t}}(),function(){let e=a();const t=e.init||{};e.init={...t}}(),s(),function(){let e=a();const t=e.loader_config||{};e.loader_config={...t}}(),a()}},2843:(e,t,r)=>{"use strict";r.d(t,{u:()=>i});var n=r(3878);function i(e,t=!1,r,i){(0,n.DD)("visibilitychange",(function(){if(t)return void("hidden"===document.visibilityState&&e());e(document.visibilityState)}),r,i)}},3434:(e,t,r)=>{"use strict";r.d(t,{YM:()=>c});var n=r(7836),i=r(5607);const o="nr@original:".concat(i.W);var a=Object.prototype.hasOwnProperty,s=!1;function c(e,t){return e||(e=n.ee),r.inPlace=function(e,t,n,i,o){n||(n="");const a="-"===n.charAt(0);for(let s=0;s<t.length;s++){const c=t[s],u=e[c];d(u)||(e[c]=r(u,a?c+n:n,i,c,o))}},r.flag=o,r;function r(t,r,n,s,c){return d(t)?t:(r||(r=""),nrWrapper[o]=t,function(e,t,r){if(Object.defineProperty&&Object.keys)try{return Object.keys(e).forEach((function(r){Object.defineProperty(t,r,{get:function(){return e[r]},set:function(t){return e[r]=t,t}})})),t}catch(e){u([e],r)}for(var n in e)a.call(e,n)&&(t[n]=e[n])}(t,nrWrapper,e),nrWrapper);function nrWrapper(){var o,a,d,l;try{a=this,o=[...arguments],d="function"==typeof n?n(o,a):n||{}}catch(t){u([t,"",[o,a,s],d],e)}i(r+"start",[o,a,s],d,c);try{return l=t.apply(a,o)}catch(e){throw i(r+"err",[o,a,e],d,c),e}finally{i(r+"end",[o,a,l],d,c)}}}function i(r,n,i,o){if(!s||t){var a=s;s=!0;try{e.emit(r,n,i,t,o)}catch(t){u([t,r,n,i],e)}s=a}}}function u(e,t){t||(t=n.ee);try{t.emit("internal-error",e)}catch(e){}}function d(e){return!(e&&"function"==typeof e&&e.apply&&!e[o])}},993:(e,t,r)=>{"use strict";r.d(t,{ET:()=>o,p_:()=>i});var n=r(860);const i={ERROR:"ERROR",WARN:"WARN",INFO:"INFO",DEBUG:"DEBUG",TRACE:"TRACE"},o="log";n.K7.logging},3969:(e,t,r)=>{"use strict";r.d(t,{TZ:()=>n,XG:()=>s,rs:()=>i,xV:()=>a,z_:()=>o});const n=r(860).K7.metrics,i="sm",o="cm",a="storeSupportabilityMetrics",s="storeEventMetrics"},6630:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewEvent},782:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewTiming},6344:(e,t,r)=>{"use strict";r.d(t,{G4:()=>i});var n=r(2614);r(860).K7.sessionReplay;const i={RECORD:"recordReplay",PAUSE:"pauseReplay",REPLAY_RUNNING:"replayRunning",ERROR_DURING_REPLAY:"errorDuringReplay"};n.g.ERROR,n.g.FULL,n.g.OFF},4234:(e,t,r)=>{"use strict";r.d(t,{W:()=>o});var n=r(7836),i=r(1687);class o{constructor(e,t){this.agentIdentifier=e,this.ee=n.ee.get(e),this.featureName=t,this.blocked=!1}deregisterDrain(){(0,i.x3)(this.agentIdentifier,this.featureName)}}},7603:(e,t,r)=>{"use strict";r.d(t,{j:()=>P});var n=r(860),i=r(2555),o=r(3371),a=r(9908),s=r(7836),c=r(1687),u=r(5289),d=r(6154),l=r(944),f=r(3969),g=r(384),p=r(6344);const h=["setErrorHandler","finished","addToTrace","addRelease","addPageAction","setCurrentRouteName","setPageViewName","setCustomAttribute","interaction","noticeError","setUserId","setApplicationVersion","start",p.G4.RECORD,p.G4.PAUSE,"log","wrapLogger"],v=["setErrorHandler","finished","addToTrace","addRelease"];var m=r(1863),b=r(2614),y=r(993);var w=r(2646),A=r(3434);function R(e,t,r,n){if("object"!=typeof t||!t||"string"!=typeof r||!r||"function"!=typeof t[r])return(0,l.R)(29);const i=function(e){return(e||s.ee).get("logger")}(e),o=(0,A.YM)(i),a=new w.y(s.P);return a.level=n.level,a.customAttributes=n.customAttributes,o.inPlace(t,[r],"wrap-logger-",a),i}function E(){const e=(0,g.pV)();h.forEach((t=>{e[t]=(...r)=>function(t,...r){let n=[];return Object.values(e.initializedAgents).forEach((e=>{e&&e.api?e.exposed&&e.api[t]&&n.push(e.api[t](...r)):(0,l.R)(38,t)})),n.length>1?n:n[0]}(t,...r)}))}const x={};function _(e,t,g=!1){t||(0,c.Ak)(e,"api");const h={};var w=s.ee.get(e),A=w.get("tracer");x[e]=b.g.OFF,w.on(p.G4.REPLAY_RUNNING,(t=>{x[e]=t}));var E="api-",_=E+"ixn-";function N(t,r,n,o){const a=(0,i.Vp)(e);return null===r?delete a.jsAttributes[t]:(0,i.x1)(e,{...a,jsAttributes:{...a.jsAttributes,[t]:r}}),j(E,n,!0,o||null===r?"session":void 0)(t,r)}function T(){}h.log=function(e,{customAttributes:t={},level:r=y.p_.INFO}={}){(0,a.p)(f.xV,["API/log/called"],void 0,n.K7.metrics,w),function(e,t,r={},i=y.p_.INFO){(0,a.p)(f.xV,["API/logging/".concat(i.toLowerCase(),"/called")],void 0,n.K7.metrics,e),(0,a.p)(y.ET,[(0,m.t)(),t,r,i],void 0,n.K7.logging,e)}(w,e,t,r)},h.wrapLogger=(e,t,{customAttributes:r={},level:i=y.p_.INFO}={})=>{(0,a.p)(f.xV,["API/wrapLogger/called"],void 0,n.K7.metrics,w),R(w,e,t,{customAttributes:r,level:i})},v.forEach((e=>{h[e]=j(E,e,!0,"api")})),h.addPageAction=j(E,"addPageAction",!0,n.K7.genericEvents),h.setPageViewName=function(t,r){if("string"==typeof t)return"/"!==t.charAt(0)&&(t="/"+t),(0,o.f)(e).customTransaction=(r||"http://custom.transaction")+t,j(E,"setPageViewName",!0)()},h.setCustomAttribute=function(e,t,r=!1){if("string"==typeof e){if(["string","number","boolean"].includes(typeof t)||null===t)return N(e,t,"setCustomAttribute",r);(0,l.R)(40,typeof t)}else(0,l.R)(39,typeof e)},h.setUserId=function(e){if("string"==typeof e||null===e)return N("enduser.id",e,"setUserId",!0);(0,l.R)(41,typeof e)},h.setApplicationVersion=function(e){if("string"==typeof e||null===e)return N("application.version",e,"setApplicationVersion",!1);(0,l.R)(42,typeof e)},h.start=()=>{try{(0,a.p)(f.xV,["API/start/called"],void 0,n.K7.metrics,w),w.emit("manual-start-all")}catch(e){(0,l.R)(23,e)}},h[p.G4.RECORD]=function(){(0,a.p)(f.xV,["API/recordReplay/called"],void 0,n.K7.metrics,w),(0,a.p)(p.G4.RECORD,[],void 0,n.K7.sessionReplay,w)},h[p.G4.PAUSE]=function(){(0,a.p)(f.xV,["API/pauseReplay/called"],void 0,n.K7.metrics,w),(0,a.p)(p.G4.PAUSE,[],void 0,n.K7.sessionReplay,w)},h.interaction=function(e){return(new T).get("object"==typeof e?e:{})};const S=T.prototype={createTracer:function(e,t){var r={},i=this,o="function"==typeof t;return(0,a.p)(f.xV,["API/createTracer/called"],void 0,n.K7.metrics,w),g||(0,a.p)(_+"tracer",[(0,m.t)(),e,r],i,n.K7.spa,w),function(){if(A.emit((o?"":"no-")+"fn-start",[(0,m.t)(),i,o],r),o)try{return t.apply(this,arguments)}catch(e){const t="string"==typeof e?new Error(e):e;throw A.emit("fn-err",[arguments,this,t],r),t}finally{A.emit("fn-end",[(0,m.t)()],r)}}}};function j(e,t,r,i){return function(){return(0,a.p)(f.xV,["API/"+t+"/called"],void 0,n.K7.metrics,w),i&&(0,a.p)(e+t,[(0,m.t)(),...arguments],r?null:this,i,w),r?void 0:this}}function k(){r.e(296).then(r.bind(r,8778)).then((({setAPI:t})=>{t(e),(0,c.Ze)(e,"api")})).catch((e=>{(0,l.R)(27,e),w.abort()}))}return["actionText","setName","setAttribute","save","ignore","onEnd","getContext","end","get"].forEach((e=>{S[e]=j(_,e,void 0,g?n.K7.softNav:n.K7.spa)})),h.setCurrentRouteName=g?j(_,"routeName",void 0,n.K7.softNav):j(E,"routeName",!0,n.K7.spa),h.noticeError=function(t,r){"string"==typeof t&&(t=new Error(t)),(0,a.p)(f.xV,["API/noticeError/called"],void 0,n.K7.metrics,w),(0,a.p)("err",[t,(0,m.t)(),!1,r,!!x[e]],void 0,n.K7.jserrors,w)},d.RI?(0,u.GG)((()=>k()),!0):k(),h}var N=r(9417),T=r(8122);const S={accountID:void 0,trustKey:void 0,agentID:void 0,licenseKey:void 0,applicationID:void 0,xpid:void 0},j={};var k=r(5284);const I=e=>{const t=e.startsWith("http");e+="/",r.p=t?e:"https://"+e};let O=!1;function P(e,t={},r,n){let{init:a,info:c,loader_config:u,runtime:l={},exposed:f=!0}=t;l.loaderType=r;const p=(0,g.pV)();c||(a=p.init,c=p.info,u=p.loader_config),(0,N.xN)(e.agentIdentifier,a||{}),function(e,t){if(!e)throw new Error("All loader-config objects require an agent identifier!");j[e]=(0,T.a)(t,S);const r=(0,g.nY)(e);r&&(r.loader_config=j[e])}(e.agentIdentifier,u||{}),c.jsAttributes??={},d.bv&&(c.jsAttributes.isWorker=!0),(0,i.x1)(e.agentIdentifier,c);const h=(0,N.D0)(e.agentIdentifier),v=[c.beacon,c.errorBeacon];O||(h.proxy.assets&&(I(h.proxy.assets),v.push(h.proxy.assets)),h.proxy.beacon&&v.push(h.proxy.beacon),E(),(0,g.US)("activatedFeatures",k.B),e.runSoftNavOverSpa&&=!0===h.soft_navigations.enabled&&h.feature_flags.includes("soft_nav")),l.denyList=[...h.ajax.deny_list||[],...h.ajax.block_internal?v:[]],l.ptid=e.agentIdentifier,(0,o.V)(e.agentIdentifier,l),e.ee=s.ee.get(e.agentIdentifier),void 0===e.api&&(e.api=_(e.agentIdentifier,n,e.runSoftNavOverSpa)),void 0===e.exposed&&(e.exposed=f),O=!0}},8374:(e,t,r)=>{r.nc=(()=>{try{return document?.currentScript?.nonce}catch(e){}return""})()},860:(e,t,r)=>{"use strict";r.d(t,{$J:()=>o,K7:()=>n,P3:()=>i});const n={ajax:"ajax",genericEvents:"generic_events",jserrors:"jserrors",logging:"logging",metrics:"metrics",pageAction:"page_action",pageViewEvent:"page_view_event",pageViewTiming:"page_view_timing",sessionReplay:"session_replay",sessionTrace:"session_trace",softNav:"soft_navigations",spa:"spa"},i={[n.pageViewEvent]:1,[n.pageViewTiming]:2,[n.metrics]:3,[n.jserrors]:4,[n.spa]:5,[n.ajax]:6,[n.sessionTrace]:7,[n.softNav]:8,[n.sessionReplay]:9,[n.logging]:10,[n.genericEvents]:11},o={[n.pageViewTiming]:"events",[n.ajax]:"events",[n.spa]:"events",[n.softNav]:"events",[n.metrics]:"jserrors",[n.jserrors]:"jserrors",[n.sessionTrace]:"browser/blobs",[n.sessionReplay]:"browser/blobs",[n.logging]:"browser/logs",[n.genericEvents]:"ins"}}},n={};function i(e){var t=n[e];if(void 0!==t)return t.exports;var o=n[e]={exports:{}};return r[e](o,o.exports,i),o.exports}i.m=r,i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.f={},i.e=e=>Promise.all(Object.keys(i.f).reduce(((t,r)=>(i.f[r](e,t),t)),[])),i.u=e=>"nr-rum-1.274.0.min.js",i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e={},t="NRBA-1.274.0.PROD:",i.l=(r,n,o,a)=>{if(e[r])e[r].push(n);else{var s,c;if(void 0!==o)for(var u=document.getElementsByTagName("script"),d=0;d<u.length;d++){var l=u[d];if(l.getAttribute("src")==r||l.getAttribute("data-webpack")==t+o){s=l;break}}if(!s){c=!0;var f={296:"sha512-gkYkZDAwQ9PwaDXs2YM+rNIdRej1Ac1mupWobRJ8eahQcXz6/sunGZCKklrzi5kWxhOGRZr2tn0rEKuLTXzfAA=="};(s=document.createElement("script")).charset="utf-8",s.timeout=120,i.nc&&s.setAttribute("nonce",i.nc),s.setAttribute("data-webpack",t+o),s.src=r,0!==s.src.indexOf(window.location.origin+"/")&&(s.crossOrigin="anonymous"),f[a]&&(s.integrity=f[a])}e[r]=[n];var g=(t,n)=>{s.onerror=s.onload=null,clearTimeout(p);var i=e[r];if(delete e[r],s.parentNode&&s.parentNode.removeChild(s),i&&i.forEach((e=>e(n))),t)return t(n)},p=setTimeout(g.bind(null,void 0,{type:"timeout",target:s}),12e4);s.onerror=g.bind(null,s.onerror),s.onload=g.bind(null,s.onload),c&&document.head.appendChild(s)}},i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="https://js-agent.newrelic.com/",(()=>{var e={840:0,374:0};i.f.j=(t,r)=>{var n=i.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var o=new Promise(((r,i)=>n=e[t]=[r,i]));r.push(n[2]=o);var a=i.p+i.u(t),s=new Error;i.l(a,(r=>{if(i.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var o=r&&("load"===r.type?"missing":r.type),a=r&&r.target&&r.target.src;s.message="Loading chunk "+t+" failed.\n("+o+": "+a+")",s.name="ChunkLoadError",s.type=o,s.request=a,n[1](s)}}),"chunk-"+t,t)}};var t=(t,r)=>{var n,o,[a,s,c]=r,u=0;if(a.some((t=>0!==e[t]))){for(n in s)i.o(s,n)&&(i.m[n]=s[n]);if(c)c(i)}for(t&&t(r);u<a.length;u++)o=a[u],i.o(e,o)&&e[o]&&e[o][0](),e[o]=0},r=self["webpackChunk:NRBA-1.274.0.PROD"]=self["webpackChunk:NRBA-1.274.0.PROD"]||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),(()=>{"use strict";i(8374);var e=i(944),t=i(6344),r=i(9566);class n{agentIdentifier;constructor(e=(0,r.LA)(16)){this.agentIdentifier=e}#e(t,...r){if("function"==typeof this.api?.[t])return this.api[t](...r);(0,e.R)(35,t)}addPageAction(e,t){return this.#e("addPageAction",e,t)}setPageViewName(e,t){return this.#e("setPageViewName",e,t)}setCustomAttribute(e,t,r){return this.#e("setCustomAttribute",e,t,r)}noticeError(e,t){return this.#e("noticeError",e,t)}setUserId(e){return this.#e("setUserId",e)}setApplicationVersion(e){return this.#e("setApplicationVersion",e)}setErrorHandler(e){return this.#e("setErrorHandler",e)}addRelease(e,t){return this.#e("addRelease",e,t)}log(e,t){return this.#e("log",e,t)}}class o extends n{#e(t,...r){if("function"==typeof this.api?.[t])return this.api[t](...r);(0,e.R)(35,t)}start(){return this.#e("start")}finished(e){return this.#e("finished",e)}recordReplay(){return this.#e(t.G4.RECORD)}pauseReplay(){return this.#e(t.G4.PAUSE)}addToTrace(e){return this.#e("addToTrace",e)}setCurrentRouteName(e){return this.#e("setCurrentRouteName",e)}interaction(){return this.#e("interaction")}wrapLogger(e,t,r){return this.#e("wrapLogger",e,t,r)}}var a=i(860),s=i(9417);const c=Object.values(a.K7);function u(e){const t={};return c.forEach((r=>{t[r]=function(e,t){return!0===(0,s.gD)(t,"".concat(e,".enabled"))}(r,e)})),t}var d=i(7603);var l=i(1687),f=i(4234),g=i(5289),p=i(6154),h=i(384);const v=e=>p.RI&&!0===(0,s.gD)(e,"privacy.cookies_enabled");function m(e){return!!(0,h.dV)().o.MO&&v(e)&&!0===(0,s.gD)(e,"session_trace.enabled")}var b=i(6389);class y extends f.W{constructor(e,t,r=!0){super(e.agentIdentifier,t),this.auto=r,this.abortHandler=void 0,this.featAggregate=void 0,this.onAggregateImported=void 0,!1===e.init[this.featureName].autoStart&&(this.auto=!1),this.auto?(0,l.Ak)(e.agentIdentifier,t):this.ee.on("manual-start-all",(0,b.J)((()=>{(0,l.Ak)(e.agentIdentifier,this.featureName),this.auto=!0,this.importAggregator(e)})))}importAggregator(t,r={}){if(this.featAggregate||!this.auto)return;let n;this.onAggregateImported=new Promise((e=>{n=e}));const o=async()=>{let o;try{if(v(this.agentIdentifier)){const{setupAgentSession:e}=await i.e(296).then(i.bind(i,3861));o=e(t)}}catch(t){(0,e.R)(20,t),this.ee.emit("internal-error",[t]),this.featureName===a.K7.sessionReplay&&this.abortHandler?.()}try{if(t.sharedAggregator)await t.sharedAggregator;else{t.sharedAggregator=i.e(296).then(i.bind(i,9337));const{EventAggregator:e}=await t.sharedAggregator;t.sharedAggregator=new e}if(!this.#t(this.featureName,o))return(0,l.Ze)(this.agentIdentifier,this.featureName),void n(!1);const{lazyFeatureLoader:e}=await i.e(296).then(i.bind(i,6103)),{Aggregate:a}=await e(this.featureName,"aggregate");this.featAggregate=new a(t,r),n(!0)}catch(t){(0,e.R)(34,t),this.abortHandler?.(),(0,l.Ze)(this.agentIdentifier,this.featureName,!0),n(!1),this.ee&&this.ee.abort()}};p.RI?(0,g.GG)((()=>o()),!0):o()}#t(e,t){switch(e){case a.K7.sessionReplay:return m(this.agentIdentifier)&&!!t;case a.K7.sessionTrace:return!!t;default:return!0}}}var w=i(6630);class A extends y{static featureName=w.T;constructor(e,t=!0){super(e,w.T,t),this.importAggregator(e)}}var R=i(9908),E=i(2843),x=i(3878),_=i(782),N=i(1863);class T extends y{static featureName=_.T;constructor(e,t=!0){super(e,_.T,t),p.RI&&((0,E.u)((()=>(0,R.p)("docHidden",[(0,N.t)()],void 0,_.T,this.ee)),!0),(0,x.sp)("pagehide",(()=>(0,R.p)("winPagehide",[(0,N.t)()],void 0,_.T,this.ee))),this.importAggregator(e))}}var S=i(3969);class j extends y{static featureName=S.TZ;constructor(e,t=!0){super(e,S.TZ,t),this.importAggregator(e)}}new class extends o{constructor(t,r){super(r),p.gm?(this.features={},(0,h.bQ)(this.agentIdentifier,this),this.desiredFeatures=new Set(t.features||[]),this.desiredFeatures.add(A),this.runSoftNavOverSpa=[...this.desiredFeatures].some((e=>e.featureName===a.K7.softNav)),(0,d.j)(this,t,t.loaderType||"agent"),this.run()):(0,e.R)(21)}get config(){return{info:this.info,init:this.init,loader_config:this.loader_config,runtime:this.runtime}}run(){try{const t=u(this.agentIdentifier),r=[...this.desiredFeatures];r.sort(((e,t)=>a.P3[e.featureName]-a.P3[t.featureName])),r.forEach((r=>{if(!t[r.featureName]&&r.featureName!==a.K7.pageViewEvent)return;if(this.runSoftNavOverSpa&&r.featureName===a.K7.spa)return;if(!this.runSoftNavOverSpa&&r.featureName===a.K7.softNav)return;const n=function(e){switch(e){case a.K7.ajax:return[a.K7.jserrors];case a.K7.sessionTrace:return[a.K7.ajax,a.K7.pageViewEvent];case a.K7.sessionReplay:return[a.K7.sessionTrace];case a.K7.pageViewTiming:return[a.K7.pageViewEvent];default:return[]}}(r.featureName).filter((e=>!(e in this.features)));n.length>0&&(0,e.R)(36,{targetFeature:r.featureName,missingDependencies:n}),this.features[r.featureName]=new r(this)}))}catch(t){(0,e.R)(22,t);for(const e in this.features)this.features[e].abortHandler?.();const r=(0,h.Zm)();delete r.initializedAgents[this.agentIdentifier]?.api,delete r.initializedAgents[this.agentIdentifier]?.features,delete this.sharedAggregator;return r.ee.get(this.agentIdentifier).abort(),!1}}}({features:[A,T,j],loaderType:"lite"})})()})();</script>
		<link rel="profile" href="http://gmpg.org/xfn/11">
		
		<!-- generics -->
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-32.png" sizes="32x32">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-57.png" sizes="57x57">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-76.png" sizes="76x76">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-96.png" sizes="96x96">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-128.png" sizes="128x128">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-192.png" sizes="192x192">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-195.png" sizes="195x195">
		<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-228.png" sizes="228x228">
		<link rel="shortcut icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon.ico">

		<!-- Android -->
		<link rel="shortcut icon" sizes="196x196" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-196.png">

		<!-- iOS -->
		<link rel="apple-touch-icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-120.png" sizes="120x120">
		<link rel="apple-touch-icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-152.png" sizes="152x152">
		<link rel="apple-touch-icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-180.png" sizes="180x180">

		<!-- Windows 8 IE 10-->
		<meta name="msapplication-TileColor" content="#FFFFFF">
		<meta name="msapplication-TileImage" content="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-144.png">

		<!-- Windows 8.1 + IE11 and above -->
		<meta name="application-name" content="University of La Verne">
		<meta name="msapplication-tooltip" content="University of La Verne website">
		<meta name="msapplication-config" content="https://laverne.edu/experience/wp-content/themes/laverne2017/img/ieconfig.xml" />

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

				
		<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO Premium plugin v23.8 (Yoast SEO v23.8) - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found | The La Verne Experience</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found | The La Verne Experience" />
	<meta property="og:site_name" content="The La Verne Experience" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://laverne.edu/experience/#website","url":"https://laverne.edu/experience/","name":"The La Verne Experience","description":"University of La Verne","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://laverne.edu/experience/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//cdn.jsdelivr.net' />
<link rel="alternate" type="application/rss+xml" title="The La Verne Experience &raquo; Feed" href="https://laverne.edu/experience/feed/" />
<link rel="alternate" type="application/rss+xml" title="The La Verne Experience &raquo; Comments Feed" href="https://laverne.edu/experience/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/laverne.edu\/experience\/wp-includes\/js\/wp-emoji-release.min.js?ver=15641fb7b8ff551f708c18e066c07e4c"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://laverne.edu/experience/wp-includes/css/dist/block-library/style.min.css?ver=15641fb7b8ff551f708c18e066c07e4c' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='cookie-consent-default-style-css' href='https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='ulv-cookie-consent-style-css' href='https://laverne.edu/experience/wp-content/plugins/ulv_cookie_consent/styles/css/style.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='theme-style-css' href='https://laverne.edu/experience/wp-content/themes/laverne2017/style.css?ver=1.2.48' type='text/css' media='all' />
<link rel='stylesheet' id='ulv-directory-views-styles-css' href='https://laverne.edu/experience/wp-content/plugins/ulv_directory_views/styles/css/style.css?ver=1.2.1' type='text/css' media='all' />
<script type="text/javascript" src="https://laverne.edu/experience/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" id="laverne2017-header-scripts-js-extra">
/* <![CDATA[ */
var laverne_header_scripts_settings = {"template_js_dir":"https:\/\/laverne.edu\/experience\/wp-content\/themes\/laverne2017\/js\/","social_feed_embed":null,"disable_gtm_container":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-content/themes/laverne2017/js/header-scripts.min.js?ver=1.1.15" id="laverne2017-header-scripts-js"></script>
<link rel="https://api.w.org/" href="https://laverne.edu/experience/wp-json/" />			<script type="text/javascript">
	            (function($) {
	              var cx = '009285304065246230251:zwfshjeknsi';
	              var gcse = document.createElement('script');
	              gcse.type = 'text/javascript';
	              gcse.async = true;
	              gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//www.google.com/cse/cse.js?cx=' + cx;
	              var s = document.getElementsByTagName('script')[0];
	              s.parentNode.insertBefore(gcse, s);
	            })(jQuery);
	        </script>
			<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-48.png" sizes="32x32" />
<link rel="icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-48.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-48.png" />
<meta name="msapplication-TileImage" content="https://laverne.edu/experience/wp-content/themes/laverne2017/img/favicon-48.png" />
	</head>

	<body class="error404 green">
									<!-- Google Tag Manager (noscript) -->
							<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P88M43B&gtm_auth=hCCvd8HHEYdgsDHnz9wt_w&gtm_preview=env-2&gtm_cookies_win=x"
							height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
							<!-- End Google Tag Manager (noscript) -->
									
		<a id="skip-link" href="#main-content-start" class="sr-only" aria-describedby="skip-button-desc">Skip to main content</a>
		<div id="skip-button-desc" class="sr-only">Bypass the primary and secondary navigation and continue reading the main body of the page</div>
		
		
		<header class="nav-header" aria-label="Site Branding and Navigation">
			<div class="mobile-header-row">
				<a class="hdr-logo-link" href="https://laverne.edu" rel="home" aria-label="Home" aria-describedby="home-logo-link-desc">
					<span id="home-logo-link-desc" class="sr-only">Return to the University of La Verne home page</span>
					<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
				</a>
				<a href="#" id="toggle-mobile-menu" role="button" aria-label="Toggle mobile menu..." aria-haspopup="true" aria-expanded="false" aria-controls="mobile-menu-drawer"><span class="glyphicon glyphicon-menu-hamburger"></span></a>
			</div>
			<div id="mobile-menu-drawer" class="mobile-menu-drawer">
				<div class="top-row">
					<div class="container-fluid">
						
						<nav class="resources-for dropdown" aria-labelledby="dLabel"><a href="#" id="dLabel" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-controls="menu-resources-for" aria-label="Resources for:...">Resources for: <span class="glyphicon glyphicon-menu-down"></span></a><ul id="menu-resources-for" class="dropdown-menu"><li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44"><a href="https://laverne.edu/prospective/">Prospective Students</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-43"><a href="https://laverne.edu/students/">Current Students</a></li>
<li id="menu-item-22708" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22708"><a href="https://laverne.edu/parents/">Parents and Families</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://laverne.edu/faculty-staff/">Faculty and Staff</a></li>
<li id="menu-item-1046" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1046"><a href="https://laverne.edu/partners">Community Partners</a></li>
<li id="menu-item-3961" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3961"><a href="https://laverne.edu/news/for-media/">For Media</a></li>
<li id="menu-item-24357" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24357"><a href="https://laverne.edu/military">Military Connected</a></li>
<li id="menu-item-1047" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1047"><a href="https://alumni.laverne.edu/">Alumni</a></li>
</ul></nav><nav class="header-quick-links" aria-label="Outreach"><ul id="menu-header-quick-links" class=""><li id="menu-item-499" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-499"><a href="https://securelb.imodules.com/s/1636/17/form.aspx?sid=1636&#038;gid=1&#038;pgid=435&#038;cid=1071">Give to La&nbsp;Verne</a></li>
<li id="menu-item-22251" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22251"><a href="https://myportal.laverne.edu/">La&nbsp;Verne Portal</a></li>
<li id="menu-item-1680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1680"><a href="https://univ.lv/info">Info Sessions</a></li>
<li id="menu-item-22841" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22841"><a href="https://laverne.edu/request-information/">Request Info</a></li>
<li id="menu-item-1758" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1758"><a href="https://laverne.edu/visit/">Visit</a></li>
<li id="menu-item-49" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a href="https://laverne.edu/apply/">Apply</a></li>
</ul></nav>
					</div>
				</div>

				<div class="main-row">
					<div class="container-fluid">

						<nav class="main-navigation">							<ul id="menu-main-menu" class="menu">
								<li>
									<a class="hdr-logo-link" href="https://laverne.edu" rel="home" aria-label="University of La Verne" aria-describedby="home-logo-link-desc">
										<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
									</a>
								</li>
								<html><body><li id="menu-item-1102" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1102"><a href="https://laverne.edu/admission/">Admission and Aid</a><a role="button" href="#" aria-label="toggle submenu Admission and Aid" aria-controls="menu-5-sub-menu-1-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-1-0" class="sub-menu">
	<li id="menu-item-1104" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1104"><a href="https://laverne.edu/admission/">Admission</a><a role="button" href="#" aria-label="toggle submenu Admission" aria-controls="menu-5-sub-menu-2-1" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
	<ul id="menu-5-sub-menu-2-1" class="sub-menu">
		<li id="menu-item-1107" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1107"><a href="https://laverne.edu/admission/undergraduate/">Undergraduate</a></li>
		<li id="menu-item-1108" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1108"><a href="https://laverne.edu/admission/graduate/">Graduate</a></li>
		<li id="menu-item-22710" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22710"><a href="https://laverne.edu/admission/transfer/">Transfers</a></li>
		<li id="menu-item-1109" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1109"><a href="https://laverne.edu/admission/international/">International</a></li>
	</ul>
</li>
	<li id="menu-item-1103" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1103"><a href="https://laverne.edu/financial-aid/">Financial Aid</a></li>
	<li id="menu-item-1105" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1105"><a href="https://laverne.edu/tuition/">Tuition and Fees</a></li>
	<li id="menu-item-26056" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-26056"><a href="https://laverne.edu/partners/">Educational Partnerships</a></li>
</ul>
</li>
<li id="menu-item-1085" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1085"><a href="https://laverne.edu/academics/">Academics</a><a role="button" href="#" aria-label="toggle submenu Academics" aria-controls="menu-5-sub-menu-3-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-3-0" class="sub-menu">
	<li id="menu-item-1076" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1076"><a href="#">Colleges</a><a role="button" href="#" aria-label="toggle submenu Colleges" aria-controls="menu-5-sub-menu-4-1" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
	<ul id="menu-5-sub-menu-4-1" class="sub-menu">
		<li id="menu-item-1077" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1077"><a href="https://artsci.laverne.edu/">College of Arts and Sciences</a></li>
		<li id="menu-item-1078" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1078"><a href="https://business.laverne.edu/">College of Business</a></li>
		<li id="menu-item-1079" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1079"><a href="https://education.laverne.edu/">LaFetra College of Education</a></li>
		<li id="menu-item-22855" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22855"><a href="https://health.laverne.edu/">Cástulo de la Rocha College of Health and Community Well-Being</a></li>
		<li id="menu-item-1080" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1080"><a href="https://law.laverne.edu/">College of Law and Public Service</a></li>
	</ul>
</li>
	<li id="menu-item-301" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-301"><a href="https://laverne.edu/programs/">Degrees and Programs</a></li>
	<li id="menu-item-1098" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1098"><a href="https://laverne.edu/locations/">Regional Campuses</a></li>
	<li id="menu-item-1095" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1095"><a href="https://laverne.edu/online/">La Verne Online</a></li>
	<li id="menu-item-1287" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1287"><a href="https://laverne.edu/extended-learning/">Extended Learning</a></li>
	<li id="menu-item-1626" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1626"><a href="https://laverne.edu/pdc/">Professional Development Courses</a></li>
	<li id="menu-item-1096" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1096"><a href="https://laverne.edu/abroad/">Study Abroad</a></li>
	<li id="menu-item-1088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1088"><a href="https://laverne.edu/academics/calendar/">Academic Calendars</a></li>
	<li id="menu-item-1094" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1094"><a href="https://library.laverne.edu/">Wilson Library</a></li>
</ul>
</li>
<li id="menu-item-1070" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1070"><a href="https://laverne.edu/life/">Life at La Verne</a><a role="button" href="#" aria-label="toggle submenu Life at La Verne" aria-controls="menu-5-sub-menu-5-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-5-0" class="sub-menu">
	<li id="menu-item-1120" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1120"><a href="https://laverne.edu/acc/">Abraham Campus Center</a></li>
	<li id="menu-item-1116" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1116"><a href="https://laverne.edu/experience/">La Verne Experience</a></li>
	<li id="menu-item-1351" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1351"><a href="https://laverne.edu/life/arts/">The Arts at La Verne</a></li>
	<li id="menu-item-1117" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1117"><a href="https://laverne.edu/student-life/">Student Life</a></li>
	<li id="menu-item-1391" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1391"><a href="https://laverne.edu/housing/">Student Housing</a></li>
	<li id="menu-item-1122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1122"><a href="https://laverne.edu/life/support-services/">Support Services</a></li>
	<li id="menu-item-1121" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1121"><a href="https://laverne.cafebonappetit.com">Dining Services</a></li>
	<li id="menu-item-1119" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1119"><a href="https://laverne.edu/diversity/">Diversity and Inclusivity</a></li>
	<li id="menu-item-23112" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23112"><a href="https://laverne.edu/commencement/">Commencement</a></li>
</ul>
</li>
<li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="https://www.leopardathletics.com/landing/index">Athletics</a></li>
<li id="menu-item-1075" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a href="https://laverne.edu/about/">About La Verne</a><a role="button" href="#" aria-label="toggle submenu About La Verne" aria-controls="menu-5-sub-menu-6-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-6-0" class="sub-menu">
	<li id="menu-item-1508" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1508"><a href="https://laverne.edu/news">News and Events</a></li>
	<li id="menu-item-1072" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1072"><a href="https://laverne.edu/locations/">Campus Locations</a></li>
	<li id="menu-item-1074" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1074"><a href="https://laverne.edu/president/">Office of the President</a></li>
	<li id="menu-item-21517" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-21517"><a href="https://laverne.edu/advancement/">University Advancement</a></li>
	<li id="menu-item-1071" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1071"><a href="https://laverne.edu/2025-vision/">2025 Strategic Vision</a></li>
	<li id="menu-item-23134" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23134"><a href="https://laverne.edu/about/accreditation/">Accreditation</a></li>
	<li id="menu-item-1073" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1073"><a href="https://laverne.edu/directory/">Staff and Faculty Directory</a></li>
</ul>
</li>
</body></html>								<li>
												<div class="search-form site-search-active" id="search-form-67465ad1d1cb7">
				<form action="https://laverne.edu/experience" method="get" id="mega_search" role="search">
					<input type="hidden" name="cx" value="009285304065246230251:zwfshjeknsi">
					<input type="hidden" name="cof" value="FORID:11">
					<input type="hidden" name="ie" value="UTF-8">
					<input type="hidden" name="sa" value="Search">
					
					<fieldset>
						<legend class="sr-only">Query Fields</legend>
						<div class="input-group cse" role="group" aria-labelledby="cse-search-desc">
							<div id="cse-search-desc" class="sr-only">laverne.edu and related sites</div>
							<label id="mega-search-query-label" class="sr-only" for="desktop-search">Search query</label>
							<input type="text" class="form-control" placeholder="Enter search terms" id="desktop-search" name="q" aria-labelledby="mega-search-query-label" aria-required="true">
							<div class="input-group-addon">
								<button type="submit" class="" aria-label="Submit">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
						</div>
						
						<div class="input-group ulv-directory hidden" role="group" aria-labelledby="directory-search-desc">
							<div id="directory-search-desc" class="sr-only">Staff and Faculty Directory</div>
							<label id="directory-search-first-name-label" class="sr-only" for="first-name-search">First name search query</label>
							<input type="text" class="form-control" placeholder="First Name" id="first-name-search" name="first_name">
							<label id="directory-search-last-name-label" class="sr-only" for="last-name-search">Last name search query</label>
							<input type="text" class="form-control" placeholder="Last Name" id="last-name-search" name="last_name">
							<div class="input-group-addon">
								<button type="submit" class="" aria-label="Submit">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
						</div>
						
						<div class="switch-mega-search-wrapper text-right" role="group" aria-labelledby="switch-mega-search-type">
							<div id="switch-mega-search-type" class="sr-only">Toggle between laverne.edu site search and Staff and Faculty Directory search</div>
							<label class="radio-inline"><input type="radio" name="search-target" id="search-target-site" value="site" checked="checked">&nbsp;Site</label>
							<label class="radio-inline"><input type="radio" name="search-target" id="search-target-people" value="people">&nbsp;People</label>
						</div>
					</fieldset>
				</form>
			</div>
												<a href="#" id="search-toggle" class="collapsed" role="button" aria-label="Open site search" data-toggle="collapse" aria-haspopup="true" aria-expanded="false" aria-controls="search-form" aria-describedby="search-toggle-desc">
										<span class="fa fa-search"></span>
									</a>
									<div id="search-toggle-desc" class="sr-only">Show or hide the site search form</div>
								</li>
							</ul>
						</nav>					</div>	
				</div>
			</div>
		</header>

		<main id="main-content">
<div class="landing-page-hero show-image">
	<a name="main-content-start"></a>
	
	<div role="img" class="bg-image" style="background-image: url('https://laverne.edu/experience/wp-content/themes/laverne2017/img/404_Header_Image_Crop-3.jpg');" aria-label="Leo Holding a 404 Sign"></div>

	<div class="container-fluid">
		<div class="title">
			<h1 id="main-title" class="sr-only">Error 404: Page not found</h1>
		</div>
	</div>

</div>

<div class="upper-region constrained">

	<article>

		<h3>We&#8217;re sorry this isn&#8217;t the spot you&#8217;re looking for.</h3>
<p>The page you trying to reach does not exist, or has been moved. Please use the menus or search box above to find what you are looking for, or skim through popular destinations below.</p>
<table class="three-column layout">
<tbody>
<tr>
<td>
<h3>Academics</h3>
<ul>
<li><a href="https://laverne.edu/programs/">Programs and Degrees</a></li>
<li><a href="https://laverne.edu/academics/calendars/">Academic Calendars</a></li>
<li><a href="https://laverne.edu/online/">La&nbsp;Verne Online</a></li>
<li><a href="https://laverne.edu/capa/">Campus Accelerated Programs for Adults</a></li>
<li><a href="https://laverne.edu/asc/">Academic Success Center</a></li>
<li><a href="https://artsci.laverne.edu/physician-assistant/">Physician Assistant Practice, MS</a></li>
<li><a href="https://artsci.laverne.edu/psyd/">Doctorate in Clinical Psychology, PsyD</a></li>
<li><a href="https://laverne.edu/advising/">Academic Advising</a></li>
</ul>
</td>
<td>
<h3>Admission</h3>
<ul>
<li><a href="https://laverne.edu/admission/">Admission at La&nbsp;Verne</a></li>
<li><a href="https://laverne.edu/admission/graduate/">Graduate Admission</a></li>
<li><a href="https://laverne.edu/admission/undergraduate/">Undergraduate Admission</a></li>
<li><a href="https://laverne.edu/admission/accelerated/">Accelerated Undergraduate Programs</a></li>
<li><a href="https://laverne.edu/tuition/">Tuition and Fees</a></li>
<li><a href="https://artsci.laverne.edu/scholarship/">Performance Scholarships</a></li>
</ul>
</td>
<td>
<h3>The University</h3>
<ul>
<li><a href="https://laverne.edu/directory/">Offices and Services Directory</a></li>
<li><a href="https://laverne.edu/hr">Office of Human Resources</a></li>
<li><a href="https://laverne.edu/financial-aid/">Office of Financial Aid</a></li>
<li><a href="https://laverne.edu/locations">Campus Locations</a></li>
<li><a href="https://laverne.edu/registrar/">Office of the Registrar</a></li>
<li><a href="https://laverne.edu/housing/">Student Housing</a></li>
<li><a href="https://laverne.edu/careers/">Career Services</a></li>
<li><a href="https://www.youvisit.com/#/vte/?data-inst=60188&#038;data-platform=v">Virtual Campus Tour</a></li>
</ul>
</td>
</tr>
</tbody>
</table>

	</article>
	
</div>

<div class="lower-region">

		
</div>

		</main>

		<footer role="contentinfo" id="the-footer">
			<div class="container-fluid">
				<div>
					<div>
						
						<div role="img" class="footer-logo" aria-label="University of La Verne logo">
							<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
						</div>

						<div class="footer-address">
							<p>1950 Third Street<br/>La Verne, CA 91750</p><p>(909) 593-3511</p><p><strong>Campus Safety:</strong><br/>(909) 448-4950</p>						</div>

					</div>
					<div role="navigation" aria-label="Footer: Quick Links">
												<nav class="menu-footer-quick-links-container"><ul id="menu-footer-quick-links" class="menu"><li id="menu-item-1065" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1065"><a href="https://laverne.edu/directory">Offices and Departments</a></li>
<li id="menu-item-87" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-87"><a href="https://laverne.edu/map/">Campus Map/Directions</a></li>
<li id="menu-item-1364" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1364"><a href="https://myportal.laverne.edu/web/parking/parking">Parking Information</a></li>
<li id="menu-item-1100" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1100"><a href="https://www.bkstr.com/lavernestore/">Campus Store</a></li>
<li id="menu-item-1066" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1066"><a href="https://laverne.edu/hr">Employment Opportunities</a></li>
<li id="menu-item-1068" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1068"><a href="https://laverne.edu/policies/">University Policies</a></li>
<li id="menu-item-1653" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1653"><a href="https://laverne.edu/policies/terms-use-privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-1067" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1067"><a href="https://laverne.edu/title-ix/">Title IX</a></li>
<li id="menu-item-1038" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1038"><a href="https://myportal.laverne.edu/web/campus-safety">Campus Safety</a></li>
<li id="menu-item-13197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13197"><a href="https://laverne.edu/alert">Emergency Alerts</a></li>
<li id="menu-item-1388" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1388"><a href="https://laverne.edu/feedback/">Feedback</a></li>
</ul></nav>					</div>
					<div role="navigation" aria-label="Footer: Resources for your community">
												<div class="h6" aria-hidden="true">Resources for:</div>
												<nav class="resources-for"><ul id="footer-resources-for-menu" class="menu"><li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44"><a href="https://laverne.edu/prospective/">Prospective Students</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-43"><a href="https://laverne.edu/students/">Current Students</a></li>
<li id="menu-item-22708" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22708"><a href="https://laverne.edu/parents/">Parents and Families</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://laverne.edu/faculty-staff/">Faculty and Staff</a></li>
<li id="menu-item-1046" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1046"><a href="https://laverne.edu/partners">Community Partners</a></li>
<li id="menu-item-3961" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3961"><a href="https://laverne.edu/news/for-media/">For Media</a></li>
<li id="menu-item-24357" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24357"><a href="https://laverne.edu/military">Military Connected</a></li>
<li id="menu-item-1047" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1047"><a href="https://alumni.laverne.edu/">Alumni</a></li>
</ul></nav>					</div>
					<div role="navigation" aria-label="Social Media">
												<div class="h6">Connect with La Verne</div>
												<nav class="social-media icon-menu"><ul id="menu-footer-social-media" class="menu"><li id="menu-item-91" class="fab fa-facebook-f menu-item menu-item-type-custom menu-item-object-custom menu-item-91"><a href="https://www.facebook.com/ULaVerne/">facebook</a></li>
<li id="menu-item-92" class="fab fa-twitter menu-item menu-item-type-custom menu-item-object-custom menu-item-92"><a href="https://twitter.com/ULaVerne/">twitter</a></li>
<li id="menu-item-93" class="fab fa-instagram menu-item menu-item-type-custom menu-item-object-custom menu-item-93"><a href="https://www.instagram.com/ULaVerne/">instagram</a></li>
<li id="menu-item-94" class="fab fa-youtube menu-item menu-item-type-custom menu-item-object-custom menu-item-94"><a href="https://www.youtube.com/user/UniversityofLaVerne">youtube</a></li>
<li id="menu-item-95" class="fab fa-linkedin-in menu-item menu-item-type-custom menu-item-object-custom menu-item-95"><a href="https://www.linkedin.com/school/ulaverne/">linkedin</a></li>
</ul></nav>					</div>
				</div>

				<div class="copyright" aria-label="Copyright Information">&copy; University of La&nbsp;Verne</div>
			</div>

			

		</footer>

		<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js?ver=1.0.0" data-cfasync="false"></script><script type="text/javascript" id="ulv-cookie-consent-script-js-extra">
/* <![CDATA[ */
var ulv_cookie_consent_settings = {"bg_color":"#4a7729","text_color":"#ffffff","dismiss_button_bg_color":"#2c5234","dismiss_button_text_color":"#ffffff","header":"","message":"The University of La Verne uses cookies to enhance the user experience. By continuing to use our sites, you are giving us your consent to do this. For more information, please review our","policy_link_text":"Privacy Policy.","policy_link_url":"https:\/\/laverne.edu\/policies\/","dismiss":"OK","allow":"","deny":"","current_url":"https:\/\/laverne.edu\/experience\/Popover%20requires%20tooltip.js","close":"\u274c","cookie_domain":"laverne.edu"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-content/plugins/ulv_cookie_consent/js/script.min.js?ver=1.2.0" id="ulv-cookie-consent-script-js"></script>
<script type="text/javascript" id="laverne2017-site-alerts-js-extra">
/* <![CDATA[ */
var ajax_object = {"ajax_url":"https:\/\/laverne.edu\/experience\/wp-admin\/admin-ajax.php","verify":"0689b530b6","autoRotate":"on","autoRotateSpeed":"10"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-content/themes/laverne2017/js/resources/site-alerts.min.js?ver=1.2.3" id="laverne2017-site-alerts-js"></script>
<script type="text/javascript" id="laverne2017-cse-search-js-extra">
/* <![CDATA[ */
var search_form_data = {"directory_search_page":"https:\/\/laverne.edu\/directory\/faculty-staff-search\/","cse_search_page":"https:\/\/laverne.edu\/experience"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/experience/wp-content/themes/laverne2017/js/search-scripts.min.js?ver=1.1.3" id="laverne2017-cse-search-js"></script>
	<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"NRJS-4e4110d68b3ad07705c","applicationID":"576718860","transactionName":"Y1FbNRNVX0BTBUULV1obeAIVXV5dHVIBVg==","queueTime":0,"applicationTime":1079,"atts":"TxZYQ1tPTE4=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>