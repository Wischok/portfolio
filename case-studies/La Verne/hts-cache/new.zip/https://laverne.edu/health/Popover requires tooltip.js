<!DOCTYPE html>
<html lang="en-US" class="no-js">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="profile" href="http://gmpg.org/xfn/11">
		
		<!-- generics -->
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-32.png" sizes="32x32">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-57.png" sizes="57x57">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-76.png" sizes="76x76">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-96.png" sizes="96x96">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-128.png" sizes="128x128">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-192.png" sizes="192x192">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-195.png" sizes="195x195">
		<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-228.png" sizes="228x228">
		<link rel="shortcut icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon.ico">

		<!-- Android -->
		<link rel="shortcut icon" sizes="196x196" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-196.png">

		<!-- iOS -->
		<link rel="apple-touch-icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-120.png" sizes="120x120">
		<link rel="apple-touch-icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-152.png" sizes="152x152">
		<link rel="apple-touch-icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-180.png" sizes="180x180">

		<!-- Windows 8 IE 10-->
		<meta name="msapplication-TileColor" content="#FFFFFF">
		<meta name="msapplication-TileImage" content="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-144.png">

		<!-- Windows 8.1 + IE11 and above -->
		<meta name="application-name" content="University of La Verne">
		<meta name="msapplication-tooltip" content="University of La Verne website">
		<meta name="msapplication-config" content="https://laverne.edu/health/wp-content/themes/laverne2017/img/ieconfig.xml" />

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

				
		<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO Premium plugin v23.8 (Yoast SEO v23.8) - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found | Student Health Services</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found | Student Health Services" />
	<meta property="og:site_name" content="Student Health Services" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://laverne.edu/health/#website","url":"https://laverne.edu/health/","name":"Student Health Services","description":"University of La Verne","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://laverne.edu/health/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//cdn.jsdelivr.net' />
<link rel="alternate" type="application/rss+xml" title="Student Health Services &raquo; Feed" href="https://laverne.edu/health/feed/" />
<link rel="alternate" type="application/rss+xml" title="Student Health Services &raquo; Comments Feed" href="https://laverne.edu/health/comments/feed/" />
<link rel="alternate" type="text/calendar" title="Student Health Services &raquo; iCal Feed" href="https://laverne.edu/health/events/?ical=1" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/laverne.edu\/health\/wp-includes\/js\/wp-emoji-release.min.js?ver=15641fb7b8ff551f708c18e066c07e4c"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='tribe-events-pro-mini-calendar-block-styles-css' href='https://laverne.edu/health/wp-content/plugins/events-calendar-pro/src/resources/css/tribe-events-pro-mini-calendar-block.min.css?ver=7.0.3' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://laverne.edu/health/wp-includes/css/dist/block-library/style.min.css?ver=15641fb7b8ff551f708c18e066c07e4c' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='cookie-consent-default-style-css' href='https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='ulv-cookie-consent-style-css' href='https://laverne.edu/health/wp-content/plugins/ulv_cookie_consent/styles/css/style.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='theme-style-css' href='https://laverne.edu/health/wp-content/themes/laverne2017/style.css?ver=1.2.48' type='text/css' media='all' />
<link rel='stylesheet' id='ulv-directory-views-styles-css' href='https://laverne.edu/health/wp-content/plugins/ulv_directory_views/styles/css/style.css?ver=1.2.1' type='text/css' media='all' />
<script type="text/javascript" src="https://laverne.edu/health/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://laverne.edu/health/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://laverne.edu/health/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" id="laverne2017-header-scripts-js-extra">
/* <![CDATA[ */
var laverne_header_scripts_settings = {"template_js_dir":"https:\/\/laverne.edu\/health\/wp-content\/themes\/laverne2017\/js\/","social_feed_embed":null,"disable_gtm_container":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/health/wp-content/themes/laverne2017/js/header-scripts.min.js?ver=1.1.15" id="laverne2017-header-scripts-js"></script>
<link rel="https://api.w.org/" href="https://laverne.edu/health/wp-json/" /><meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="https://laverne.edu/health"><link rel="alternate" href="https://laverne.edu/health/wp-json/tribe/events/v1/" />
<!-- Dynamic Widgets by QURL loaded - http://www.dynamic-widgets.com //-->
			<script type="text/javascript">
	            (function($) {
	              var cx = '009285304065246230251:zwfshjeknsi';
	              var gcse = document.createElement('script');
	              gcse.type = 'text/javascript';
	              gcse.async = true;
	              gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//www.google.com/cse/cse.js?cx=' + cx;
	              var s = document.getElementsByTagName('script')[0];
	              s.parentNode.insertBefore(gcse, s);
	            })(jQuery);
	        </script>
			<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-48.png" sizes="32x32" />
<link rel="icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-48.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-48.png" />
<meta name="msapplication-TileImage" content="https://laverne.edu/health/wp-content/themes/laverne2017/img/favicon-48.png" />
	</head>

	<body class="error404 tribe-no-js green">
									<!-- Google Tag Manager (noscript) -->
							<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P88M43B&gtm_auth=hCCvd8HHEYdgsDHnz9wt_w&gtm_preview=env-2&gtm_cookies_win=x"
							height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
							<!-- End Google Tag Manager (noscript) -->
									
		<a id="skip-link" href="#main-content-start" class="sr-only" aria-describedby="skip-button-desc">Skip to main content</a>
		<div id="skip-button-desc" class="sr-only">Bypass the primary and secondary navigation and continue reading the main body of the page</div>
		
		
		<header class="nav-header" aria-label="Site Branding and Navigation">
			<div class="mobile-header-row">
				<a class="hdr-logo-link" href="https://laverne.edu" rel="home" aria-label="Home" aria-describedby="home-logo-link-desc">
					<span id="home-logo-link-desc" class="sr-only">Return to the University of La Verne home page</span>
					<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
				</a>
				<a href="#" id="toggle-mobile-menu" role="button" aria-label="Toggle mobile menu..." aria-haspopup="true" aria-expanded="false" aria-controls="mobile-menu-drawer"><span class="glyphicon glyphicon-menu-hamburger"></span></a>
			</div>
			<div id="mobile-menu-drawer" class="mobile-menu-drawer">
				<div class="top-row">
					<div class="container-fluid">
						
						<nav class="resources-for dropdown" aria-labelledby="dLabel"><a href="#" id="dLabel" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-controls="menu-resources-for" aria-label="Resources for:...">Resources for: <span class="glyphicon glyphicon-menu-down"></span></a><ul id="menu-resources-for" class="dropdown-menu"><li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44"><a href="https://laverne.edu/prospective/">Prospective Students</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-43"><a href="https://laverne.edu/students/">Current Students</a></li>
<li id="menu-item-22708" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22708"><a href="https://laverne.edu/parents/">Parents and Families</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://laverne.edu/faculty-staff/">Faculty and Staff</a></li>
<li id="menu-item-1046" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1046"><a href="https://laverne.edu/partners">Community Partners</a></li>
<li id="menu-item-3961" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3961"><a href="https://laverne.edu/news/for-media/">For Media</a></li>
<li id="menu-item-24357" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24357"><a href="https://laverne.edu/military">Military Connected</a></li>
<li id="menu-item-1047" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1047"><a href="https://alumni.laverne.edu/">Alumni</a></li>
</ul></nav><nav class="header-quick-links" aria-label="Outreach"><ul id="menu-header-quick-links" class=""><li id="menu-item-499" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-499"><a href="https://securelb.imodules.com/s/1636/17/form.aspx?sid=1636&#038;gid=1&#038;pgid=435&#038;cid=1071">Give to La&nbsp;Verne</a></li>
<li id="menu-item-22251" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22251"><a href="https://myportal.laverne.edu/">La&nbsp;Verne Portal</a></li>
<li id="menu-item-1680" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1680"><a href="https://univ.lv/info">Info Sessions</a></li>
<li id="menu-item-22841" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22841"><a href="https://laverne.edu/request-information/">Request Info</a></li>
<li id="menu-item-1758" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1758"><a href="https://laverne.edu/visit/">Visit</a></li>
<li id="menu-item-49" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-49"><a href="https://laverne.edu/apply/">Apply</a></li>
</ul></nav>
					</div>
				</div>

				<div class="main-row">
					<div class="container-fluid">

						<nav class="main-navigation">							<ul id="menu-main-menu" class="menu">
								<li>
									<a class="hdr-logo-link" href="https://laverne.edu" rel="home" aria-label="University of La Verne" aria-describedby="home-logo-link-desc">
										<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
									</a>
								</li>
								<html><body><li id="menu-item-1102" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1102"><a href="https://laverne.edu/admission/">Admission and Aid</a><a role="button" href="#" aria-label="toggle submenu Admission and Aid" aria-controls="menu-5-sub-menu-1-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-1-0" class="sub-menu">
	<li id="menu-item-1104" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1104"><a href="https://laverne.edu/admission/">Admission</a><a role="button" href="#" aria-label="toggle submenu Admission" aria-controls="menu-5-sub-menu-2-1" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
	<ul id="menu-5-sub-menu-2-1" class="sub-menu">
		<li id="menu-item-1107" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1107"><a href="https://laverne.edu/admission/undergraduate/">Undergraduate</a></li>
		<li id="menu-item-1108" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1108"><a href="https://laverne.edu/admission/graduate/">Graduate</a></li>
		<li id="menu-item-22710" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22710"><a href="https://laverne.edu/admission/transfer/">Transfers</a></li>
		<li id="menu-item-1109" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1109"><a href="https://laverne.edu/admission/international/">International</a></li>
	</ul>
</li>
	<li id="menu-item-1103" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1103"><a href="https://laverne.edu/financial-aid/">Financial Aid</a></li>
	<li id="menu-item-1105" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1105"><a href="https://laverne.edu/tuition/">Tuition and Fees</a></li>
	<li id="menu-item-26056" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-26056"><a href="https://laverne.edu/partners/">Educational Partnerships</a></li>
</ul>
</li>
<li id="menu-item-1085" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1085"><a href="https://laverne.edu/academics/">Academics</a><a role="button" href="#" aria-label="toggle submenu Academics" aria-controls="menu-5-sub-menu-3-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-3-0" class="sub-menu">
	<li id="menu-item-1076" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1076"><a href="#">Colleges</a><a role="button" href="#" aria-label="toggle submenu Colleges" aria-controls="menu-5-sub-menu-4-1" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
	<ul id="menu-5-sub-menu-4-1" class="sub-menu">
		<li id="menu-item-1077" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1077"><a href="https://artsci.laverne.edu/">College of Arts and Sciences</a></li>
		<li id="menu-item-1078" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1078"><a href="https://business.laverne.edu/">College of Business</a></li>
		<li id="menu-item-1079" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1079"><a href="https://education.laverne.edu/">LaFetra College of Education</a></li>
		<li id="menu-item-22855" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22855"><a href="https://health.laverne.edu/">Cástulo de la Rocha College of Health and Community Well-Being</a></li>
		<li id="menu-item-1080" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1080"><a href="https://law.laverne.edu/">College of Law and Public Service</a></li>
	</ul>
</li>
	<li id="menu-item-301" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-301"><a href="https://laverne.edu/programs/">Degrees and Programs</a></li>
	<li id="menu-item-1098" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1098"><a href="https://laverne.edu/locations/">Regional Campuses</a></li>
	<li id="menu-item-1095" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1095"><a href="https://laverne.edu/online/">La Verne Online</a></li>
	<li id="menu-item-1287" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1287"><a href="https://laverne.edu/extended-learning/">Extended Learning</a></li>
	<li id="menu-item-1626" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1626"><a href="https://laverne.edu/pdc/">Professional Development Courses</a></li>
	<li id="menu-item-1096" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1096"><a href="https://laverne.edu/abroad/">Study Abroad</a></li>
	<li id="menu-item-1088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1088"><a href="https://laverne.edu/academics/calendar/">Academic Calendars</a></li>
	<li id="menu-item-1094" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1094"><a href="https://library.laverne.edu/">Wilson Library</a></li>
</ul>
</li>
<li id="menu-item-1070" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1070"><a href="https://laverne.edu/life/">Life at La Verne</a><a role="button" href="#" aria-label="toggle submenu Life at La Verne" aria-controls="menu-5-sub-menu-5-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-5-0" class="sub-menu">
	<li id="menu-item-1120" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1120"><a href="https://laverne.edu/acc/">Abraham Campus Center</a></li>
	<li id="menu-item-1116" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1116"><a href="https://laverne.edu/experience/">La Verne Experience</a></li>
	<li id="menu-item-1351" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1351"><a href="https://laverne.edu/life/arts/">The Arts at La Verne</a></li>
	<li id="menu-item-1117" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1117"><a href="https://laverne.edu/student-life/">Student Life</a></li>
	<li id="menu-item-1391" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1391"><a href="https://laverne.edu/housing/">Student Housing</a></li>
	<li id="menu-item-1122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1122"><a href="https://laverne.edu/life/support-services/">Support Services</a></li>
	<li id="menu-item-1121" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1121"><a href="https://laverne.cafebonappetit.com">Dining Services</a></li>
	<li id="menu-item-1119" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1119"><a href="https://laverne.edu/diversity/">Diversity and Inclusivity</a></li>
	<li id="menu-item-23112" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23112"><a href="https://laverne.edu/commencement/">Commencement</a></li>
</ul>
</li>
<li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="https://www.leopardathletics.com/landing/index">Athletics</a></li>
<li id="menu-item-1075" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a href="https://laverne.edu/about/">About La Verne</a><a role="button" href="#" aria-label="toggle submenu About La Verne" aria-controls="menu-5-sub-menu-6-0" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-menu-down"></span></a>
<ul id="menu-5-sub-menu-6-0" class="sub-menu">
	<li id="menu-item-1508" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1508"><a href="https://laverne.edu/news">News and Events</a></li>
	<li id="menu-item-1072" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1072"><a href="https://laverne.edu/locations/">Campus Locations</a></li>
	<li id="menu-item-1074" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1074"><a href="https://laverne.edu/president/">Office of the President</a></li>
	<li id="menu-item-21517" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-21517"><a href="https://laverne.edu/advancement/">University Advancement</a></li>
	<li id="menu-item-1071" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1071"><a href="https://laverne.edu/2025-vision/">2025 Strategic Vision</a></li>
	<li id="menu-item-23134" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23134"><a href="https://laverne.edu/about/accreditation/">Accreditation</a></li>
	<li id="menu-item-1073" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1073"><a href="https://laverne.edu/directory/">Staff and Faculty Directory</a></li>
</ul>
</li>
</body></html>								<li>
												<div class="search-form site-search-active" id="search-form-67465ee645da6">
				<form action="https://laverne.edu/health" method="get" id="mega_search" role="search">
					<input type="hidden" name="cx" value="009285304065246230251:zwfshjeknsi">
					<input type="hidden" name="cof" value="FORID:11">
					<input type="hidden" name="ie" value="UTF-8">
					<input type="hidden" name="sa" value="Search">
					
					<fieldset>
						<legend class="sr-only">Query Fields</legend>
						<div class="input-group cse" role="group" aria-labelledby="cse-search-desc">
							<div id="cse-search-desc" class="sr-only">laverne.edu and related sites</div>
							<label id="mega-search-query-label" class="sr-only" for="desktop-search">Search query</label>
							<input type="text" class="form-control" placeholder="Enter search terms" id="desktop-search" name="q" aria-labelledby="mega-search-query-label" aria-required="true">
							<div class="input-group-addon">
								<button type="submit" class="" aria-label="Submit">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
						</div>
						
						<div class="input-group ulv-directory hidden" role="group" aria-labelledby="directory-search-desc">
							<div id="directory-search-desc" class="sr-only">Staff and Faculty Directory</div>
							<label id="directory-search-first-name-label" class="sr-only" for="first-name-search">First name search query</label>
							<input type="text" class="form-control" placeholder="First Name" id="first-name-search" name="first_name">
							<label id="directory-search-last-name-label" class="sr-only" for="last-name-search">Last name search query</label>
							<input type="text" class="form-control" placeholder="Last Name" id="last-name-search" name="last_name">
							<div class="input-group-addon">
								<button type="submit" class="" aria-label="Submit">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
						</div>
						
						<div class="switch-mega-search-wrapper text-right" role="group" aria-labelledby="switch-mega-search-type">
							<div id="switch-mega-search-type" class="sr-only">Toggle between laverne.edu site search and Staff and Faculty Directory search</div>
							<label class="radio-inline"><input type="radio" name="search-target" id="search-target-site" value="site" checked="checked">&nbsp;Site</label>
							<label class="radio-inline"><input type="radio" name="search-target" id="search-target-people" value="people">&nbsp;People</label>
						</div>
					</fieldset>
				</form>
			</div>
												<a href="#" id="search-toggle" class="collapsed" role="button" aria-label="Open site search" data-toggle="collapse" aria-haspopup="true" aria-expanded="false" aria-controls="search-form" aria-describedby="search-toggle-desc">
										<span class="fa fa-search"></span>
									</a>
									<div id="search-toggle-desc" class="sr-only">Show or hide the site search form</div>
								</li>
							</ul>
						</nav>					</div>	
				</div>
			</div>
		</header>

		<main id="main-content">
<div class="landing-page-hero show-image">
	<a name="main-content-start"></a>
	
	<div role="img" class="bg-image" style="background-image: url('https://laverne.edu/health/wp-content/themes/laverne2017/img/404_Header_Image_Crop-3.jpg');" aria-label="Leo Holding a 404 Sign"></div>

	<div class="container-fluid">
		<div class="title">
			<h1 id="main-title" class="sr-only">Error 404: Page not found</h1>
		</div>
	</div>

</div>

<div class="upper-region constrained">

	<article>

		<h3>We&#8217;re sorry this isn&#8217;t the spot you&#8217;re looking for.</h3>
<p>The page you trying to reach does not exist, or has been moved. Please use the menus or search box above to find what you are looking for, or skim through popular destinations below.</p>
<table class="three-column layout">
<tbody>
<tr>
<td>
<h3>Academics</h3>
<ul>
<li><a href="https://laverne.edu/programs/">Programs and Degrees</a></li>
<li><a href="https://laverne.edu/academics/calendars/">Academic Calendars</a></li>
<li><a href="https://laverne.edu/online/">La&nbsp;Verne Online</a></li>
<li><a href="https://laverne.edu/capa/">Campus Accelerated Programs for Adults</a></li>
<li><a href="https://laverne.edu/asc/">Academic Success Center</a></li>
<li><a href="https://artsci.laverne.edu/physician-assistant/">Physician Assistant Practice, MS</a></li>
<li><a href="https://artsci.laverne.edu/psyd/">Doctorate in Clinical Psychology, PsyD</a></li>
<li><a href="https://laverne.edu/advising/">Academic Advising</a></li>
</ul>
</td>
<td>
<h3>Admission</h3>
<ul>
<li><a href="https://laverne.edu/admission/">Admission at La&nbsp;Verne</a></li>
<li><a href="https://laverne.edu/admission/graduate/">Graduate Admission</a></li>
<li><a href="https://laverne.edu/admission/undergraduate/">Undergraduate Admission</a></li>
<li><a href="https://laverne.edu/admission/accelerated/">Accelerated Undergraduate Programs</a></li>
<li><a href="https://laverne.edu/tuition/">Tuition and Fees</a></li>
<li><a href="https://artsci.laverne.edu/scholarship/">Performance Scholarships</a></li>
</ul>
</td>
<td>
<h3>The University</h3>
<ul>
<li><a href="https://laverne.edu/directory/">Offices and Services Directory</a></li>
<li><a href="https://laverne.edu/hr">Office of Human Resources</a></li>
<li><a href="https://laverne.edu/financial-aid/">Office of Financial Aid</a></li>
<li><a href="https://laverne.edu/locations">Campus Locations</a></li>
<li><a href="https://laverne.edu/registrar/">Office of the Registrar</a></li>
<li><a href="https://laverne.edu/housing/">Student Housing</a></li>
<li><a href="https://laverne.edu/careers/">Career Services</a></li>
<li><a href="https://www.youvisit.com/#/vte/?data-inst=60188&#038;data-platform=v">Virtual Campus Tour</a></li>
</ul>
</td>
</tr>
</tbody>
</table>

	</article>
	
</div>

<div class="lower-region">

		
</div>

		</main>

		<footer role="contentinfo" id="the-footer">
			<div class="container-fluid">
				<div>
					<div>
						
						<div role="img" class="footer-logo" aria-label="University of La Verne logo">
							<!--<svg xmlns="http://www.w3.org/2000/svg" width="152" height="56" viewBox="0 0 1000 334">-->
	<!--<path d="M7.7 320.9h310v10.1H7.7V320.9zM280.4 293.9H44.9v10.1h235.4V293.9zM283.7 119.6c0-64.3-54.3-116.6-121-116.6 -66.7 0-121 52.3-121 116.6h10.4c0-58.7 49.6-106.5 110.6-106.5S273.2 60.8 273.2 119.6H283.7M101.6 97.6c-4.3 9.1-3.9 20.8-3.9 20.8h54.4L101.6 97.6zM115.2 76.5c-8.2 8.2-11.3 16.3-11.3 16.3l49.5 20.6L115.2 76.5zM136.7 61.9c-11 4.1-17.5 10.8-17.5 10.8l36.4 35L136.7 61.9zM160.3 56.9c-10.7 0-18.3 3.2-18.3 3.2l18.3 44.9L160.3 56.9zM183.8 60c-9.9-3.7-18.5-3.1-18.5-3.1v48.1L183.8 60zM206 72.9c-9-8-17-10.9-17-10.9l-19.1 45.5L206 72.9zM221.6 92.8c-3.5-9-11.3-15.8-11.3-15.8l-37.8 36.3L221.6 92.8zM173.6 118.5h54.2c0 0-0.8-15.3-4.2-20.7L173.6 118.5zM108.1 141.2h42v103.1h-42V141.2zM160.5 131.1H97.6v123.2h62.9V131.1zM175.9 141.2h41.3v103.1h-41.3V141.2zM227.7 131.1H165.5v123.2h62.2V131.1zM227.7 266.9H97.6v10.1h130V266.9zM255.9 119.1c0-49.4-41.8-89.5-93.2-89.5 -51.4 0-93.2 40.2-93.2 89.5l0.1 5v153.1h10.4V119.1l-0.1-2.8c1.6-42.5 38.1-76.7 82.7-76.7 44.2 0 80.4 33.4 82.7 75.3v162.3h10.4L255.9 119.1zM391.9 144.6v9.4h-21.6v101.3h36.3c10.9 0 12.7-5.7 19.6-35.6h7.2v45.2h-99.1v-9.6h20.5V154h-20.5v-9.4H391.9zM472.6 266.1c-15.1 0-23.8-8.7-23.8-21.6 0-5.4 1.8-10.7 5.7-14.8 6.5-6.5 15.3-8.9 31.6-11.4 11.3-1.8 13.1-2.2 13.1-5.3v-8.1c0-12.2-6.1-16.6-17.2-16.6 -6.5 0-12 1.7-15.9 4.8 3.1 1.7 5 4.6 5 8.5 0 5.4-3.7 9.4-9.6 9.4 -5.9 0-9.8-4.2-9.8-10 0-12 15.5-20.5 32.7-20.5 19 0 29.2 8.1 29.2 24.9v43.4c0 5.7 1.8 7.4 5.5 7.4 3.1 0 5.4-2.6 7.4-7.4l5.5 3.1c-4.2 9.4-8.9 13.8-17.2 13.8 -7.6 0-13.8-4.4-14-15.3h-0.6C494.7 259.9 483.8 266.1 472.6 266.1M478.8 256.4c9.8 0 20.3-8.1 20.3-17.7v-16.4c-1.7 0.6-4.6 1.1-9 1.8 -18.8 3-25.6 6.8-25.6 17.9C464.4 251.2 469.2 256.4 478.8 256.4M559.6 154h-15.5v-9.4h51.7v9.4h-19l33.2 92.3h1.1l35.4-92.3h-16.2v-9.4h40.4v9.4h-12.9l-44.3 111.6h-12L559.6 154zM674 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.7c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H674zM697.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C716.3 198.8 709.8 188.3 697.1 188.3M743.6 255.3h13.8v-63.8h-13.8v-9.6h27.9v19.6c5.4-14 15.5-20.7 25.1-20.7 8.5 0 13.5 5.7 13.5 12.7 0 5.9-4.2 10.7-10 10.7 -5.5 0-10-3.7-10-9.6 0-1.1 0.2-2.4 0.7-3.5 -9.2-0.9-16.6 10.7-19 19.4v44.8h16.2v9.6h-44.5V255.3zM816.5 255.3h13.8v-63.8h-13.8v-9.6h27.9v21.4c9.8-17 20.7-22.7 31.4-22.7 14 0 22.5 9.2 22.5 26.2v48.5h13.8v9.6h-40.8v-9.6h12.7v-42.1c0-7.7-1.3-13.7-4.8-17.2 -2.6-2.8-6.3-3.9-10.5-3.9 -12.2 0-24 13.5-24 26.9v36.2h12.5v9.6h-40.8V255.3zM934 224.1c0.4 21.6 10.9 32.7 26.6 32.7 10.1 0 18.6-3.9 23.6-16.2h7.8c-5 17.2-17.3 26-34.5 26 -24.2 0-38.9-17.5-38.9-42.2 0-25.3 17.3-43.9 39.5-43.9 24.2 0 34.9 21.8 34.3 43.7H934zM957.1 188.3c-12.2 0-21 9.4-22.9 27.9h43.4C976.3 198.8 969.8 188.3 957.1 188.3M452.8 98.1c0 9-6.5 14.6-15 14.6 -8.5 0-15-5.6-15-14.6V74.5h6.6v23.3c0 3.7 2 8.5 8.4 8.5 6.4 0 8.4-4.8 8.4-8.5V74.5h6.6V98.1zM468.9 74.5h8.8l18 27.7 0.1 0.1h-0.1l0.1-0.1V74.5h6.6v37.2h-8.4l-18.4-28.5h-0.1v28.5h-6.6V74.5zM518.4 74.5h6.6v37.2h-6.6V74.5zM536.8 74.5h7.6l10.1 28.1 10.5-28.1h7.1l-15 37.2h-5.7L536.8 74.5zM584.1 74.5h24.6v6h-18v9.2h17.1v6h-17.1v10.1h19v6h-25.6V74.5zM624.1 74.5h12.9c7.2 0 13.9 2.3 13.9 10.7 0 5.4-3.1 9.3-8.6 10.1l9.9 16.5h-8l-8.6-15.8h-4.8v15.8h-6.6V74.5zM635.8 90.3c3.7 0 8.1-0.3 8.1-5.2 0-4.4-4.1-4.9-7.5-4.9h-5.7v10.1H635.8zM683.3 82.5c-1.4-2-3.9-2.9-6.5-2.9 -3.1 0-6.1 1.4-6.1 4.8 0 7.5 17.7 3.2 17.7 16.5 0 8-6.3 11.9-13.6 11.9 -4.6 0-9.1-1.4-12.2-5l5-4.8c1.6 2.5 4.4 3.9 7.4 3.9 3 0 6.5-1.7 6.5-5.1 0-8.2-17.7-3.5-17.7-16.8 0-7.7 6.8-11.2 13.7-11.2 3.9 0 7.8 1.1 10.7 3.8L683.3 82.5zM703 74.5h6.6v37.2h-6.6V74.5zM733.3 80.5h-11.4v-6h29.4v6h-11.4v31.2h-6.6V80.5zM772.8 95.8l-14-21.3h8.3l9.1 14.8 9.2-14.8h7.9l-14 21.3v15.9h-6.6V95.8zM826.1 93.3c0-11.9 8.2-19.7 19.7-19.7 11.6-0.2 19.8 7.6 19.8 19.5 0 11.6-8.2 19.4-19.8 19.6C834.3 112.7 826.1 104.9 826.1 93.3M833.1 92.8c0 7.9 5.1 13.8 12.8 13.8 7.7 0 12.8-5.9 12.8-13.8 0-7.4-5.1-13.3-12.8-13.3C838.2 79.5 833.1 85.4 833.1 92.8M879.8 74.5h24v6h-17.4v9.8h16.4v6h-16.4v15.5h-6.6V74.5z"/>-->
<!--</svg>-->



	<?xml version="1.0" encoding="utf-8"?>
	<!-- Generator: Adobe Illustrator 19.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Artwork" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 100.8 36"  width="152" height="56"  style="enable-background:new 0 0 100.8 36;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#2D4734;}
</style>
<g>
	<g>
		<g>
			<g>
				<path class="st0" d="M91.4,9.8c0,1.9-1.5,3.6-3.2,3.6c-1.4,0-2.3-1-2.3-2.4c0-1.9,1.5-3.6,3.2-3.6C90.6,7.4,91.4,8.4,91.4,9.8z
					 M89.2,8c-1.2,0-2,2.1-2,3.5c0,0.8,0.4,1.3,1,1.3c1.2,0,2-2.1,2-3.5C90.2,8.4,89.9,8,89.2,8z"/>
				<path class="st0" d="M90.9,14.6c0-0.4,0.3-0.8,0.8-0.8c0.4,0,0.6,0.3,0.6,0.6c0,0.2-0.1,0.4-0.2,0.5c0.4,0,0.6-0.2,1-2.1
					l0.9-4.4h-1.2L93,7.6h1.2c0.4-2.1,1.6-3.1,2.9-3.1c1,0,1.4,0.6,1.4,1.1c0,0.6-0.4,1.1-0.9,1.1C97.3,6.6,97,6.4,97,6
					c0-0.2,0.1-0.6,0.4-0.8c-0.1-0.1-0.2-0.1-0.3-0.1c-0.9,0-1.2,0.7-1.5,2.2l-0.1,0.4h1.7l-0.2,0.7h-1.6l-0.9,4.1
					c-0.5,2.3-1.6,3-2.5,3C91.2,15.4,90.9,15.1,90.9,14.6z"/>
			</g>
		</g>
		<g>
			<g>
				<path class="st0" d="M3.1,9.7V2.6H1.4V1.4h5.4v1.2H5v6.5c0,2.3,1.2,3.2,3.4,3.2c1,0,1.6-0.3,2.2-0.8c0.6-0.6,0.7-1.4,0.7-2.8
					V2.6H9.3V1.4h4.9v1.2h-1.7v7.1c0,2-1.7,3.9-4.8,3.9C4.7,13.6,3.1,12,3.1,9.7z"/>
				<path class="st0" d="M14.4,12.1h1.3V6.2h-1.3V5h3v2.1c0.9-1.6,1.9-2.2,3.1-2.2c1.3,0,2.2,1,2.2,2.6v4.6H24v1.2h-4.2v-1.2H21v-4
					c0-0.6-0.1-1.1-0.5-1.4c-0.2-0.2-0.6-0.4-1-0.4c-1,0-2.2,1-2.2,2.7v3.1h1.2v1.2h-4.2V12.1z"/>
				<path class="st0" d="M25,12.1h1.5V6.2H25V5h3.2v7.1h1.5v1.2H25V12.1z M26.1,2.1c0-0.7,0.5-1.2,1.2-1.2c0.7,0,1.2,0.5,1.2,1.2
					c0,0.7-0.5,1.2-1.2,1.2C26.5,3.3,26.1,2.8,26.1,2.1z"/>
				<path class="st0" d="M30.8,6.2h-1.2V5H34v1.2h-1.4l2,5.5h0.1l2-5.5h-1.2V5h3.5v1.2h-1l-2.8,7.2h-1.6L30.8,6.2z"/>
				<path class="st0" d="M41.1,9.3c0.1,2,0.9,3.1,2.5,3.1c1,0,1.8-0.4,2.3-1.5h0.9c-0.5,1.8-1.8,2.7-3.6,2.7c-2.5,0-4-1.8-4-4.2
					c0-2.5,1.7-4.4,4.1-4.4c2.5,0,3.6,2.2,3.5,4.4H41.1z M41.1,8.4h4c-0.1-1.5-0.7-2.6-1.9-2.6C42,5.8,41.2,6.6,41.1,8.4z"/>
				<path class="st0" d="M47.8,12.1h1.3V6.2h-1.3V5h3v1.9c0.4-1.4,1.5-2,2.4-2c0.9,0,1.4,0.6,1.4,1.4c0,0.6-0.5,1.2-1.1,1.2
					c-0.6,0-1.1-0.4-1.1-1.1c0-0.1,0-0.2,0-0.3c-0.8,0-1.4,0.9-1.7,2v4h1.6v1.2h-4.6V12.1z"/>
				<path class="st0" d="M55.6,10.3h1.1c0.5,1.3,1.5,2.2,2.6,2.2c1,0,1.4-0.5,1.4-1.2c0-0.7-0.6-1.1-2.2-1.5c-2-0.6-2.8-1.2-2.8-2.6
					c0-1.3,1.2-2.5,2.9-2.5c0.8,0,1.6,0.3,2,1l0.2-1h1.1v2.8h-1.1c-0.6-1.2-1.1-2-2.2-2c-0.6,0-1.3,0.4-1.3,1c0,0.7,0.6,1.1,2.1,1.5
					c1.9,0.5,2.8,1.1,2.8,2.5c0,1.2-1.1,2.6-3,2.6c-1,0-1.9-0.4-2.4-1.1l-0.2,1.1h-1V10.3z"/>
				<path class="st0" d="M63.5,12.1H65V6.2h-1.5V5h3.2v7.1h1.5v1.2h-4.7V12.1z M64.6,2.1c0-0.7,0.5-1.2,1.2-1.2
					c0.7,0,1.2,0.5,1.2,1.2c0,0.7-0.5,1.2-1.2,1.2C65.1,3.3,64.6,2.8,64.6,2.1z"/>
				<path class="st0" d="M71.8,2.9v2.2h2.7v1.1h-2.7v4.9c0,0.8,0.2,1.2,1,1.2c0.5,0,0.9-0.5,1.3-1.4l0.8,0.3
					c-0.5,1.6-1.4,2.2-2.6,2.2c-1.4,0-2.2-0.8-2.2-2.2v-5h-1.6V5.1h1.6V3.1L71.8,2.9z"/>
				<path class="st0" d="M77.7,14.8c0,0.2-0.1,0.5-0.1,0.6c0.7-0.2,1.2-0.5,1.7-2.1l-2.9-7h-1.2V5h4.4v1.2h-1.4l1.9,5.2l2-5.2H81V5
					h3.5v1.2h-1.1l-2.9,6.9c-1.1,2.6-2.2,3.2-3.4,3.2c-1.1,0-1.7-0.6-1.7-1.4c0-0.6,0.5-1.2,1.1-1.2C77.3,13.7,77.7,14.2,77.7,14.8z
					"/>
			</g>
		</g>
		<g>
			<path class="st0" d="M10.3,17.2v1.8h-3v14.1H11c2.2,0,2.6-0.5,3.9-4.8h1.3v6.6H1.6v-1.8h3V18.9h-3v-1.8H10.3z"/>
			<path class="st0" d="M18.3,31.8c0-0.9,0.3-1.6,0.9-2.3c1-1,2.3-1.3,4.6-1.6c1.6-0.2,1.9-0.3,1.9-0.8v-1.3c0-1.6-0.8-2.2-2.4-2.2
				c-0.8,0-1.4,0.2-2.1,0.5c0.5,0.2,0.8,0.8,0.8,1.3c0,0.8-0.6,1.5-1.6,1.5c-1,0-1.6-0.8-1.6-1.6c0-2,2.3-3.1,5.1-3.1
				c2.8,0,4.4,1.2,4.4,3.7v6.2c0,0.6,0.2,0.9,0.8,0.9c0.4,0,0.7-0.4,1-1l0.9,0.6c-0.6,1.5-1.6,2.1-2.8,2.1c-1.1,0-2.2-0.6-2.2-2.2
				h-0.1c-0.7,1.3-2.4,2.2-4,2.2C19.6,35,18.3,33.7,18.3,31.8z M25.7,30.8v-2.1c-0.2,0.1-0.5,0.2-1.2,0.3c-2.6,0.4-3.4,0.7-3.4,2.3
				c0,1.2,0.6,2,2,2C24.3,33.3,25.7,32.2,25.7,30.8z"/>
			<path class="st0" d="M34.8,18.9h-2.4v-1.8h8.3v1.8h-2.8l4.5,12.9h0.2l4.8-12.9h-2.2v-1.8h6.2v1.8h-1.9l-6.2,16h-2.5L34.8,18.9z"
				/>
			<path class="st0" d="M51.7,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.4,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H51.7z M51.7,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C53,23.8,51.9,24.8,51.7,27.6z"/>
			<path class="st0" d="M62,33.1h2v-8.8h-2v-1.8h4.4v2.8c0.6-2.1,2.2-3,3.6-3c1.4,0,2.2,0.9,2.2,2.1c0,0.9-0.7,1.8-1.6,1.8
				c-0.9,0-1.7-0.6-1.7-1.6c0-0.1,0-0.3,0.1-0.5c-1.2-0.1-2,1.3-2.5,2.9v6h2.3v1.8H62V33.1z"/>
			<path class="st0" d="M73,33.1h2v-8.8h-2v-1.8h4.4v3.1c1.4-2.3,2.9-3.3,4.6-3.3c2,0,3.3,1.4,3.3,3.8v6.9h2v1.8H81v-1.8h1.8v-5.9
				c0-0.9-0.2-1.7-0.7-2.2c-0.4-0.3-0.8-0.5-1.5-0.5c-1.5,0-3.2,1.5-3.2,4v4.7h1.8v1.8H73V33.1z"/>
			<path class="st0" d="M90.9,28.9c0.1,3,1.4,4.5,3.8,4.5c1.5,0,2.6-0.6,3.4-2.3h1.3c-0.7,2.6-2.6,4-5.3,4c-3.8,0-5.9-2.7-5.9-6.3
				c0-3.7,2.6-6.5,6.1-6.5c3.7,0,5.3,3.3,5.2,6.5H90.9z M91,27.6h5.9c-0.2-2.3-1-3.8-2.8-3.8C92.3,23.8,91.2,24.8,91,27.6z"/>
		</g>
	</g>
</g>
</svg>
						</div>

						<div class="footer-address">
							<p>1950 Third Street<br/>La Verne, CA 91750</p><p>(909) 593-3511</p><p><strong>Campus Safety:</strong><br/>(909) 448-4950</p>						</div>

					</div>
					<div role="navigation" aria-label="Footer: Quick Links">
												<nav class="menu-footer-quick-links-container"><ul id="menu-footer-quick-links" class="menu"><li id="menu-item-1065" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1065"><a href="https://laverne.edu/directory">Offices and Departments</a></li>
<li id="menu-item-87" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-87"><a href="https://laverne.edu/map/">Campus Map/Directions</a></li>
<li id="menu-item-1364" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1364"><a href="https://myportal.laverne.edu/web/parking/parking">Parking Information</a></li>
<li id="menu-item-1100" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1100"><a href="https://www.bkstr.com/lavernestore/">Campus Store</a></li>
<li id="menu-item-1066" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1066"><a href="https://laverne.edu/hr">Employment Opportunities</a></li>
<li id="menu-item-1068" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1068"><a href="https://laverne.edu/policies/">University Policies</a></li>
<li id="menu-item-1653" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1653"><a href="https://laverne.edu/policies/terms-use-privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-1067" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1067"><a href="https://laverne.edu/title-ix/">Title IX</a></li>
<li id="menu-item-1038" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1038"><a href="https://myportal.laverne.edu/web/campus-safety">Campus Safety</a></li>
<li id="menu-item-13197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13197"><a href="https://laverne.edu/alert">Emergency Alerts</a></li>
<li id="menu-item-1388" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1388"><a href="https://laverne.edu/feedback/">Feedback</a></li>
</ul></nav>					</div>
					<div role="navigation" aria-label="Footer: Resources for your community">
												<div class="h6" aria-hidden="true">Resources for:</div>
												<nav class="resources-for"><ul id="footer-resources-for-menu" class="menu"><li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44"><a href="https://laverne.edu/prospective/">Prospective Students</a></li>
<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-43"><a href="https://laverne.edu/students/">Current Students</a></li>
<li id="menu-item-22708" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22708"><a href="https://laverne.edu/parents/">Parents and Families</a></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://laverne.edu/faculty-staff/">Faculty and Staff</a></li>
<li id="menu-item-1046" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1046"><a href="https://laverne.edu/partners">Community Partners</a></li>
<li id="menu-item-3961" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3961"><a href="https://laverne.edu/news/for-media/">For Media</a></li>
<li id="menu-item-24357" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24357"><a href="https://laverne.edu/military">Military Connected</a></li>
<li id="menu-item-1047" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1047"><a href="https://alumni.laverne.edu/">Alumni</a></li>
</ul></nav>					</div>
					<div role="navigation" aria-label="Social Media">
												<div class="h6">Connect with La Verne</div>
												<nav class="social-media icon-menu"><ul id="menu-footer-social-media" class="menu"><li id="menu-item-91" class="fab fa-facebook-f menu-item menu-item-type-custom menu-item-object-custom menu-item-91"><a href="https://www.facebook.com/ULaVerne/">facebook</a></li>
<li id="menu-item-92" class="fab fa-twitter menu-item menu-item-type-custom menu-item-object-custom menu-item-92"><a href="https://twitter.com/ULaVerne/">twitter</a></li>
<li id="menu-item-93" class="fab fa-instagram menu-item menu-item-type-custom menu-item-object-custom menu-item-93"><a href="https://www.instagram.com/ULaVerne/">instagram</a></li>
<li id="menu-item-94" class="fab fa-youtube menu-item menu-item-type-custom menu-item-object-custom menu-item-94"><a href="https://www.youtube.com/user/UniversityofLaVerne">youtube</a></li>
<li id="menu-item-95" class="fab fa-linkedin-in menu-item menu-item-type-custom menu-item-object-custom menu-item-95"><a href="https://www.linkedin.com/school/ulaverne/">linkedin</a></li>
</ul></nav>					</div>
				</div>

				<div class="copyright" aria-label="Copyright Information">&copy; University of La&nbsp;Verne</div>
			</div>

			

		</footer>

				<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		<script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */ </script><script type="text/javascript" src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js?ver=1.0.0" data-cfasync="false"></script><script type="text/javascript" id="ulv-cookie-consent-script-js-extra">
/* <![CDATA[ */
var ulv_cookie_consent_settings = {"bg_color":"#4a7729","text_color":"#ffffff","dismiss_button_bg_color":"#2c5234","dismiss_button_text_color":"#ffffff","header":"","message":"The University of La Verne uses cookies to enhance the user experience. By continuing to use our sites, you are giving us your consent to do this. For more information, please review our","policy_link_text":"Privacy Policy.","policy_link_url":"https:\/\/laverne.edu\/policies\/","dismiss":"OK","allow":"","deny":"","current_url":"https:\/\/laverne.edu\/health\/Popover%20requires%20tooltip.js","close":"\u274c","cookie_domain":"laverne.edu"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/health/wp-content/plugins/ulv_cookie_consent/js/script.min.js?ver=1.2.0" id="ulv-cookie-consent-script-js"></script>
<script type="text/javascript" id="laverne2017-site-alerts-js-extra">
/* <![CDATA[ */
var ajax_object = {"ajax_url":"https:\/\/laverne.edu\/health\/wp-admin\/admin-ajax.php","verify":"0689b530b6","autoRotate":"on","autoRotateSpeed":"10"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/health/wp-content/themes/laverne2017/js/resources/site-alerts.min.js?ver=1.2.3" id="laverne2017-site-alerts-js"></script>
<script type="text/javascript" id="laverne2017-cse-search-js-extra">
/* <![CDATA[ */
var search_form_data = {"directory_search_page":"https:\/\/laverne.edu\/directory\/faculty-staff-search\/","cse_search_page":"https:\/\/laverne.edu\/health"};
/* ]]> */
</script>
<script type="text/javascript" src="https://laverne.edu/health/wp-content/themes/laverne2017/js/search-scripts.min.js?ver=1.1.3" id="laverne2017-cse-search-js"></script>
	</body>
</html>